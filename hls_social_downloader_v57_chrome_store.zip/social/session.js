/**
 * 社群媒體登入狀態偵測與定向貼文解析模組 (Session & Direct Post Extractor)
 * 專為 Section 容器定向解析打造：只針對指定 Post ID / URL 發起請求，精準獲取官方音畫合一 Progressive MP4
 */

const social = {
  /**
   * 檢查各社群平台登入 Cookie
   */
  async checkSessions() {
    const results = {
      facebook: false,
      instagram: false
    };

    try {
      const fbCookie = await chrome.cookies.get({ url: 'https://www.facebook.com', name: 'c_user' });
      results.facebook = Boolean(fbCookie && fbCookie.value);
    } catch (e) {
      console.warn('檢查 Facebook 登入狀態失敗：', e);
    }

    try {
      const igCookie = await chrome.cookies.get({ url: 'https://www.instagram.com', name: 'sessionid' });
      results.instagram = Boolean(igCookie && igCookie.value);
    } catch (e) {
      console.warn('檢查 Instagram 登入狀態失敗：', e);
    }

    return results;
  },

  cleanUrl(url) {
    if (!url) return '';
    let u = url
      .replace(/\\u0026/g, '&')
      .replace(/\\u002F/g, '/')
      .replace(/\\\//g, '/')
      .replace(/&amp;/g, '&');

    try {
      const parsed = new URL(u);
      parsed.searchParams.delete('bytestart');
      parsed.searchParams.delete('byteend');
      return parsed.href;
    } catch (e) {
      return u.replace(/([?&])bytestart=\d+(&?)/, '$1').replace(/([?&])byteend=\d+(&?)/, '$1');
    }
  },

  /**
   * 解析 Facebook 單一特定影片或 Reels (定向解析，杜絕干擾)
   */
  async parseFacebook(url) {
    if (!url || url === 'https://www.facebook.com/' || url === 'https://www.facebook.com') {
      throw new Error('請傳入具體的 Facebook 影片、Reels 或貼文專屬連結！');
    }

    const res = await fetch(url, {
      credentials: 'include',
      headers: {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8'
      }
    });
    const html = await res.text();

    // 優先尋找音畫合一的 Progressive 高畫質 MP4
    const hdMatch = html.match(/"browser_native_hd_url":"([^"]+)"/) ||
                    html.match(/"playable_url_quality_hd":"([^"]+)"/) ||
                    html.match(/"hd_src":"([^"]+)"/) ||
                    html.match(/"hd_src_no_ratelimit":"([^"]+)"/);
    const sdMatch = html.match(/"browser_native_sd_url":"([^"]+)"/) ||
                    html.match(/"playable_url":"([^"]+)"/) ||
                    html.match(/"sd_src_no_ratelimit":"([^"]+)"/) ||
                    html.match(/"sd_src":"([^"]+)"/);
    const ogVideoMatch = html.match(/<meta\s+property="og:video(?::url|:secure_url)?"\s+content="([^"]+)"/i);
    const titleMatch = html.match(/<title>([^<]+)<\/title>/i);

    let videoUrl = '';
    let quality = '標準畫質';
    if (hdMatch && hdMatch[1]) {
      videoUrl = this.cleanUrl(hdMatch[1]);
      quality = '1080P/720P 高畫質 (音畫合一)';
    } else if (sdMatch && sdMatch[1]) {
      videoUrl = this.cleanUrl(sdMatch[1]);
      quality = '標清 (音畫合一)';
    } else if (ogVideoMatch && ogVideoMatch[1]) {
      videoUrl = this.cleanUrl(ogVideoMatch[1]);
    }

    if (!videoUrl) {
      throw new Error('未能在該 Facebook 貼文中提取到 Progressive MP4 串流。');
    }

    const title = titleMatch ? titleMatch[1].replace(/ \| Facebook/g, '').trim() : 'Facebook_影片';
    return {
      url: videoUrl,
      title: `${title} [${quality}]`,
      ext: 'mp4',
      type: 'video/mp4',
      platform: 'Facebook'
    };
  },

  /**
   * 解析 Instagram 單一貼文、Reels、照片或限時動態 (定向 API 優先)
   */
  async parseInstagram(url) {
    if (!url) throw new Error('請傳入有效的 Instagram 連結！');

    // 嘗試從 URL 提取 shortcode (如 /p/C123/ 或 /reel/D456/)
    const codeMatch = url.match(/(?:p|reel|reels)\/([A-Za-z0-9_-]+)/);
    const shortcode = codeMatch ? codeMatch[1] : null;

    // 途徑 1：優先請求 Instagram 官方輕量 JSON 端點 (__a=1&__d=dis)
    if (shortcode) {
      try {
        const apiUrl = `https://www.instagram.com/p/${shortcode}/?__a=1&__d=dis`;
        const apiRes = await fetch(apiUrl, {
          credentials: 'include',
          headers: {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
            'X-Requested-With': 'XMLHttpRequest',
            'Accept': '*/*'
          }
        });

        if (apiRes.ok) {
          const data = await apiRes.json();
          const item = data.graphql?.shortcode_media || data.items?.[0];
          if (item) {
            if (item.is_video || item.video_url) {
              const vUrl = this.cleanUrl(item.video_url || item.video_versions?.[0]?.url);
              if (vUrl) {
                return {
                  url: vUrl,
                  title: `Instagram_影片_${shortcode} [音畫合一]`,
                  ext: 'mp4',
                  type: 'video/mp4',
                  platform: 'Instagram'
                };
              }
            } else if (item.display_url || item.image_versions2) {
              const imgUrl = this.cleanUrl(item.display_url || item.image_versions2?.candidates?.[0]?.url);
              if (imgUrl) {
                return {
                  url: imgUrl,
                  title: `Instagram_照片_${shortcode} [原圖]`,
                  ext: 'jpg',
                  type: 'image/jpeg',
                  platform: 'Instagram'
                };
              }
            }
          }
        }
      } catch (e) {
        // API 限制時退回途徑 2
      }
    }

    // 途徑 2：標準頁面 HTML 深度提取
    const res = await fetch(url, {
      credentials: 'include',
      headers: {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8'
      }
    });
    const html = await res.text();

    const titleMatch = html.match(/<title>([^<]+)<\/title>/i);
    const title = titleMatch ? titleMatch[1].replace(/ • Instagram photos and videos/g, '').replace(/ \| Instagram/g, '').trim() : 'Instagram_媒體';

    // 尋找 Progressive MP4 影片
    const videoMatch = html.match(/"video_url":"([^"]+)"/) || html.match(/<meta\s+property="og:video(?::url|:secure_url)?"\s+content="([^"]+)"/i);
    if (videoMatch && videoMatch[1]) {
      return {
        url: this.cleanUrl(videoMatch[1]),
        title: `${title} [音畫合一]`,
        ext: 'mp4',
        type: 'video/mp4',
        platform: 'Instagram'
      };
    }

    // 尋找高畫質原圖
    const imgMatch = html.match(/"display_url":"([^"]+)"/) || html.match(/<meta\s+property="og:image"\s+content="([^"]+)"/i);
    if (imgMatch && imgMatch[1]) {
      return {
        url: this.cleanUrl(imgMatch[1]),
        title: `${title} [高畫質照片]`,
        ext: 'jpg',
        type: 'image/jpeg',
        platform: 'Instagram'
      };
    }

    throw new Error('未能在該貼文中解析出媒體直連，請確認貼文權限或是否為限時動態！');
  },

  /**
   * 統一定向解析入口
   */
  async parseUrl(url) {
    if (!url) throw new Error('網址不可為空');

    if (url.includes('facebook.com')) {
      return this.parseFacebook(url);
    } else if (url.includes('instagram.com')) {
      return this.parseInstagram(url);
    } else {
      throw new Error('目前僅支援 Facebook 與 Instagram 平台定向解析！');
    }
  }
};
