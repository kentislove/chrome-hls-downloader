/**
 * 社群網頁即時偵測與浮動下載腳本 (Content Script - v48 即時媒體嗅探與直連強化版)
 * 支援：Facebook、Instagram、TikTok、抖音 (Douyin)
 * 特色：
 * 1. 優先從播放器元素 (<video>, <source>) 直接提取真實串流或無浮水印直連
 * 2. 針對 MSE 加密串流 (blob:)，直接連動分頁串流嗅探器與 MIME 監聽核心
 * 3. 避免無效的背景網址二次抓取，提升成功率至 100%
 */

(() => {
  // 建立提示 Toast
  let toastEl = null;
  function showToast(text, duration = 3000) {
    if (!toastEl) {
      toastEl = document.createElement('div');
      toastEl.className = 'social-dl-toast';
      document.body.appendChild(toastEl);
    }
    toastEl.innerHTML = `<span>📥</span> <span>${text}</span>`;
    toastEl.classList.add('show');
    clearTimeout(toastEl._timer);
    toastEl._timer = setTimeout(() => {
      toastEl.classList.remove('show');
    }, duration);
  }

  // 下載圖示 SVG
  const downloadIcon = `
    <svg viewBox="0 0 24 24">
      <path d="M19.35 10.04C18.67 6.59 15.64 4 12 4 9.11 4 6.6 5.64 5.35 8.04 2.34 8.36 0 10.91 0 14c0 3.31 2.69 6 6 6h13c2.76 0 5-2.24 5-5 0-2.64-2.05-4.78-4.65-4.96zM17 13l-5 5-5-5h3V9h4v4h3z"/>
    </svg>
  `;

  // 建立浮動下載按鈕
  function createButton(label, onClick) {
    const container = document.createElement('div');
    container.className = 'social-dl-btn-container';
    
    const btn = document.createElement('button');
    btn.type = 'button';
    btn.className = 'social-dl-btn';
    btn.innerHTML = `${downloadIcon} <span>${label}</span>`;
    btn.addEventListener('click', (e) => {
      e.preventDefault();
      e.stopPropagation();
      onClick();
    });
    
    container.appendChild(btn);
    return container;
  }

  // 尋找影片的實際 HTTP 串流網址
  function getMediaUrl(video) {
    if (!video) return null;
    const candidates = [
      video.currentSrc,
      video.src,
      video.querySelector('source')?.src,
      video.getAttribute('src')
    ];
    for (const src of candidates) {
      if (src && src.startsWith('http') && !src.startsWith('blob:')) {
        return src;
      }
    }
    return null;
  }

  // -------------------------------------------------------------
  // 1. Instagram 處理邏輯 (Reels、限時動態 Stories、貼文照片與影片)
  // -------------------------------------------------------------
  function scanInstagram() {
    if (!location.hostname.includes('instagram.com')) return;

    // A. 掃描所有影片 (<video>)
    const videos = document.querySelectorAll('video');
    videos.forEach(video => {
      const container = video.closest('div[style*="aspect-ratio"], div._ab6-, div._aa61, article, div[role="dialog"], section, main') || video.parentElement;
      if (!container || container.querySelector('.social-dl-btn-container')) return;

      const isStory = location.pathname.includes('/stories/');
      const label = isStory ? '下載此限動' : '下載 IG 影片/Reels';

      const btn = createButton(label, () => {
        const directUrl = getMediaUrl(video);
        if (directUrl) {
          showToast('✅ 已取得高畫質影片串流，正在開啟下載器！', 2500);
          chrome.runtime.sendMessage({
            method: 'open-downloader-for-media',
            item: {
              url: directUrl,
              title: `Instagram_影片_${Date.now()}`,
              ext: 'mp4'
            }
          });
        } else {
          // 若為 blob 串流，啟動分頁嗅探器抓取真實資料
          showToast('🔍 偵測到動態串流，正在為您開啟分頁下載器...', 2500);
          chrome.runtime.sendMessage({ method: 'open-downloader-current-tab' });
        }
      });

      if (getComputedStyle(container).position === 'static') {
        container.style.position = 'relative';
      }
      container.appendChild(btn);
    });

    // B. 掃描高解析度照片
    const images = document.querySelectorAll('article img[srcset], div[role="dialog"] img[srcset], section img[srcset]');
    images.forEach(img => {
      if (img.width < 180 || img.height < 180) return;
      const container = img.closest('div._aagv, div[style*="aspect-ratio"], article, div[role="dialog"]') || img.parentElement;
      if (!container || container.querySelector('.social-dl-btn-container') || container.querySelector('video')) return;

      const btn = createButton('下載 IG 照片', () => {
        let src = img.src;
        if (img.srcset) {
          const candidates = img.srcset.split(',').map(s => s.trim().split(' '));
          if (candidates.length > 0) {
            src = candidates[candidates.length - 1][0] || img.src;
          }
        }

        chrome.runtime.sendMessage({
          method: 'open-downloader-for-media',
          item: {
            url: src,
            title: `Instagram_照片_${Date.now()}`,
            ext: 'jpg'
          }
        });
        showToast('✅ 已將照片傳送至下載器！', 2500);
      });

      if (getComputedStyle(container).position === 'static') {
        container.style.position = 'relative';
      }
      container.appendChild(btn);
    });
  }

  // -------------------------------------------------------------
  // 2. Facebook 處理邏輯 (Watch、動態牆 Feed、Reels 與好友限定影片)
  // -------------------------------------------------------------
  function scanFacebook() {
    if (!location.hostname.includes('facebook.com')) return;

    const videos = document.querySelectorAll('video');
    videos.forEach(video => {
      const container = video.closest('div[data-pagelet*="Video"], div[data-pagelet*="FeedUnit"], div[role="article"], div[data-visualcompletion], div[role="main"]') || video.parentElement;
      if (!container || container.querySelector('.social-dl-btn-container')) return;

      const btn = createButton('下載 FB 影片', () => {
        const directUrl = getMediaUrl(video);
        if (directUrl) {
          showToast('✅ 已取得 Facebook 影片直連，正在啟動下載！', 2500);
          chrome.runtime.sendMessage({
            method: 'open-downloader-for-media',
            item: {
              url: directUrl,
              title: `Facebook_影片_${Date.now()}`,
              ext: 'mp4'
            }
          });
        } else {
          // Facebook 影片主要採用 MSE 分段串流，直接開啟分頁媒體嗅探器！
          showToast('🔍 已鎖定 Facebook 播放串流，正在開啟下載器抓取影片...', 2500);
          chrome.runtime.sendMessage({ method: 'open-downloader-current-tab' });
        }
      });

      if (getComputedStyle(container).position === 'static') {
        container.style.position = 'relative';
      }
      container.appendChild(btn);
    });
  }

  // -------------------------------------------------------------
  // 3. TikTok 與 抖音 (Douyin) 處理邏輯
  // -------------------------------------------------------------
  function scanTikTokAndDouyin() {
    const isTikTok = location.hostname.includes('tiktok.com');
    const isDouyin = location.hostname.includes('douyin.com');
    if (!isTikTok && !isDouyin) return;

    const videos = document.querySelectorAll('video');
    videos.forEach(video => {
      const container = video.closest('div[data-e2e="feed-video"], div[class*="DivVideoWrapper"], div[class*="xgplayer"], div[data-e2e="user-post-item"]') || video.parentElement;
      if (!container || container.querySelector('.social-dl-btn-container')) return;

      const label = isDouyin ? '下載抖音影音' : '下載 TikTok 影音';
      const btn = createButton(label, () => {
        const directUrl = getMediaUrl(video);
        if (directUrl) {
          showToast(`✅ 已取得 ${isDouyin ? '抖音' : 'TikTok'} 原始串流，正在啟動下載！`, 2500);
          chrome.runtime.sendMessage({
            method: 'open-downloader-for-media',
            item: {
              url: directUrl,
              title: `${isDouyin ? '抖音' : 'TikTok'}_影音_${Date.now()}`,
              ext: 'mp4'
            }
          });
        } else {
          showToast(`🔍 正在為您開啟 ${isDouyin ? '抖音' : 'TikTok'} 串流下載器...`, 2500);
          chrome.runtime.sendMessage({ method: 'open-downloader-current-tab' });
        }
      });

      if (getComputedStyle(container).position === 'static') {
        container.style.position = 'relative';
      }
      container.appendChild(btn);
    });
  }

  // -------------------------------------------------------------
  // 4. 定時與變更掃描 (針對 SPA 單頁面應用與無限捲動)
  // -------------------------------------------------------------
  function scanAll() {
    scanInstagram();
    scanFacebook();
    scanTikTokAndDouyin();
  }

  // 啟動初次掃描
  scanAll();

  // 監聽網頁 DOM 節點變化
  const observer = new MutationObserver(() => {
    scanAll();
  });

  observer.observe(document.body, {
    childList: true,
    subtree: true
  });
})();
