/**
 * 社群平台 Session 與媒體解析模組 (v45)
 * 支援平台：Facebook、Instagram、TikTok
 * 功能：
 * 1. 讀取 Chrome 瀏覽器當前 Cookie 判斷是否處於已登入狀態
 * 2. 存取好友限定/追蹤者限定私人內容 (自動夾帶瀏覽器 Session 憑證)
 * 3. 解析 Reels、限時動態 (Stories)、貼文照片與去浮水印影片網址
 */

const social = {
  /**
   * 檢查 Facebook, Instagram, TikTok 當前登入狀態
   */
  async checkSessions() {
    const results = {
      facebook: { loggedIn: false, userId: null, note: '未登入' },
      instagram: { loggedIn: false, userId: null, note: '未登入' },
      tiktok: { loggedIn: false, userId: null, note: '未登入' }
    };

    try {
      // 1. Facebook Session 檢查 (c_user = 使用者編號, xs = 連線金鑰)
      const fbUser = await chrome.cookies.get({ url: 'https://www.facebook.com', name: 'c_user' });
      const fbXs = await chrome.cookies.get({ url: 'https://www.facebook.com', name: 'xs' });
      if (fbUser && fbUser.value) {
        results.facebook = {
          loggedIn: true,
          userId: fbUser.value,
          note: `已登入 (用戶編號: ${fbUser.value})`
        };
      }

      // 2. Instagram Session 檢查 (sessionid = 登入憑證, ds_user_id = 用戶 ID)
      const igSession = await chrome.cookies.get({ url: 'https://www.instagram.com', name: 'sessionid' });
      const igUser = await chrome.cookies.get({ url: 'https://www.instagram.com', name: 'ds_user_id' });
      if (igSession && igSession.value) {
        results.instagram = {
          loggedIn: true,
          userId: igUser ? igUser.value : '已登入用戶',
          note: igUser ? `已登入 (用戶編號: ${igUser.value})` : '已登入 (可存取私人限動/貼文)'
        };
      }

      // 3. TikTok Session 檢查 (sessionid = 登入憑證)
      const ttSession = await chrome.cookies.get({ url: 'https://www.tiktok.com', name: 'sessionid' });
      if (ttSession && ttSession.value) {
        results.tiktok = {
          loggedIn: true,
          userId: '已登入用戶',
          note: '已登入'
        };
      }
    } catch (err) {
      console.warn('檢查社群 Session 時發生錯誤：', err);
    }

    return results;
  },

  /**
   * 清理並還原跳脫字元 (反斜線、Unicode 編碼)
   */
  cleanUrl(str) {
    if (!str) return '';
    return str
      .replace(/\\u0025/g, '%')
      .replace(/\\u0026/g, '&')
      .replace(/\\u002F/g, '/')
      .replace(/\\\//g, '/')
      .replace(/&amp;/g, '&');
  },

  /**
   * 解析 Facebook 影片或 Reels
   */
  async parseFacebook(url) {
    const res = await fetch(url, {
      credentials: 'include',
      headers: {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8'
      }
    });
    const html = await res.text();

    // 嘗試尋找高畫質與標準畫質 MP4 串流
    const hdMatch = html.match(/"playable_url_quality_hd":"([^"]+)"/);
    const sdMatch = html.match(/"playable_url":"([^"]+)"/) || html.match(/"sd_src_no_ratelimit":"([^"]+)"/) || html.match(/"sd_src":"([^"]+)"/);
    const ogVideoMatch = html.match(/<meta\s+property="og:video(?::url)?"\s+content="([^"]+)"/i);
    const titleMatch = html.match(/<title>([^<]+)<\/title>/i);

    let videoUrl = '';
    let quality = '標準畫質';
    if (hdMatch && hdMatch[1]) {
      videoUrl = this.cleanUrl(hdMatch[1]);
      quality = '1080P/720P 高畫質 (HD)';
    } else if (sdMatch && sdMatch[1]) {
      videoUrl = this.cleanUrl(sdMatch[1]);
      quality = '標清 (SD)';
    } else if (ogVideoMatch && ogVideoMatch[1]) {
      videoUrl = this.cleanUrl(ogVideoMatch[1]);
    }

    if (!videoUrl) {
      throw new Error('未能在 Facebook 頁面找到可下載的影片串流，請確認您已登入並擁有觀看權限！');
    }

    const title = titleMatch ? titleMatch[1].replace(/ \| Facebook/g, '').trim() : 'Facebook_影片';
    return {
      url: videoUrl,
      title: `${title} [${quality}]`,
      ext: 'mp4',
      type: 'video/mp4',
      platform: 'Facebook'
    };
  },

  /**
   * 解析 Instagram 貼文、Reels、照片或限時動態
   */
  async parseInstagram(url) {
    // 檢查是否為限時動態 Stories
    const isStory = url.includes('/stories/');

    const res = await fetch(url, {
      credentials: 'include',
      headers: {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8'
      }
    });
    const html = await res.text();

    const titleMatch = html.match(/<title>([^<]+)<\/title>/i);
    const title = titleMatch ? titleMatch[1].replace(/ • Instagram photos and videos/g, '').replace(/ \| Instagram/g, '').trim() : 'Instagram_媒體';

    // 1. 尋找影片
    const videoMatch = html.match(/"video_url":"([^"]+)"/) || html.match(/<meta\s+property="og:video(?::url)?"\s+content="([^"]+)"/i);
    if (videoMatch && videoMatch[1]) {
      return {
        url: this.cleanUrl(videoMatch[1]),
        title: `${title} [影片/Reels]`,
        ext: 'mp4',
        type: 'video/mp4',
        platform: 'Instagram'
      };
    }

    // 2. 尋找高畫質照片
    const imgMatch = html.match(/"display_url":"([^"]+)"/) || html.match(/<meta\s+property="og:image"\s+content="([^"]+)"/i);
    if (imgMatch && imgMatch[1]) {
      return {
        url: this.cleanUrl(imgMatch[1]),
        title: `${title} [高畫質照片]`,
        ext: 'jpg',
        type: 'image/jpeg',
        platform: 'Instagram'
      };
    }

    throw new Error('未能在 Instagram 頁面找到媒體檔案。若是私人帳號或限時動態，請確認已在瀏覽器登入 Instagram 並已追蹤該帳號！');
  },

  /**
   * 解析 TikTok 無浮水印影音
   */
  async parseTikTok(url) {
    const res = await fetch(url, {
      credentials: 'include',
      headers: {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8'
      }
    });
    const html = await res.text();

    // 尋找無浮水印 playAddr 或 downloadAddr
    const playAddrMatch = html.match(/"playAddr":"([^"]+)"/) || html.match(/"downloadAddr":"([^"]+)"/);
    const titleMatch = html.match(/<title>([^<]+)<\/title>/i);
    const title = titleMatch ? titleMatch[1].replace(/ \| TikTok/g, '').trim() : 'TikTok_影音';

    if (playAddrMatch && playAddrMatch[1]) {
      const cleanPlayUrl = this.cleanUrl(playAddrMatch[1]);
      return {
        url: cleanPlayUrl,
        title: `${title} [無浮水印高清]`,
        ext: 'mp4',
        type: 'video/mp4',
        platform: 'TikTok'
      };
    }

    // 備用方案：尋找 <video src="...">
    const videoSrcMatch = html.match(/<video[^>]+src="([^">]+)"/i);
    if (videoSrcMatch && videoSrcMatch[1]) {
      return {
        url: this.cleanUrl(videoSrcMatch[1]),
        title: `${title} [TikTok 影片]`,
        ext: 'mp4',
        type: 'video/mp4',
        platform: 'TikTok'
      };
    }

    throw new Error('未能在 TikTok 頁面找到影片串流，請確認網址是否正確！');
  },

  /**
   * 根據網址自動識別社群平台並進行解析
   */
  async parseUrl(rawUrl) {
    const url = rawUrl.trim();
    if (/facebook\.com|fb\.watch/i.test(url)) {
      return await this.parseFacebook(url);
    } else if (/instagram\.com/i.test(url)) {
      return await this.parseInstagram(url);
    } else if (/tiktok\.com/i.test(url)) {
      return await this.parseTikTok(url);
    } else {
      // 非社群平台，以標準格式回傳
      return {
        url,
        title: url.split('/').pop().split('?')[0] || '媒體檔案',
        ext: url.includes('.m3u8') ? 'm3u8' : 'mp4',
        type: 'media',
        platform: 'General'
      };
    }
  }
};

// 於全域環境註冊，供 Service Worker 及背景腳本取用
self.social = social;
