/**
 * 社群網頁即時偵測與浮動下載腳本 (Content Script)
 * 支援：Facebook, Instagram, TikTok
 * 功能：自動在瀏覽中的限時動態、Reels、私人/公開影片與照片上方插入快速下載按鈕
 */

(() => {
  // 建立提示 Toast
  let toastEl = null;
  function showToast(text, duration = 3000) {
    if (!toastEl) {
      toastEl = document.createElement('div');
      toastEl.className = 'social-dl-toast';
      document.body.appendChild(toastEl);
    }
    toastEl.innerHTML = `<span>📥</span> <span>${text}</span>`;
    toastEl.classList.add('show');
    clearTimeout(toastEl._timer);
    toastEl._timer = setTimeout(() => {
      toastEl.classList.remove('show');
    }, duration);
  }

  // 下載圖示 SVG
  const downloadIcon = `
    <svg viewBox="0 0 24 24">
      <path d="M19.35 10.04C18.67 6.59 15.64 4 12 4 9.11 4 6.6 5.64 5.35 8.04 2.34 8.36 0 10.91 0 14c0 3.31 2.69 6 6 6h13c2.76 0 5-2.24 5-5 0-2.64-2.05-4.78-4.65-4.96zM17 13l-5 5-5-5h3V9h4v4h3z"/>
    </svg>
  `;

  // 建立浮動下載按鈕
  function createButton(label, onClick) {
    const container = document.createElement('div');
    container.className = 'social-dl-btn-container';
    
    const btn = document.createElement('button');
    btn.type = 'button';
    btn.className = 'social-dl-btn';
    btn.innerHTML = `${downloadIcon} <span>${label}</span>`;
    btn.addEventListener('click', (e) => {
      e.preventDefault();
      e.stopPropagation();
      onClick();
    });
    
    container.appendChild(btn);
    return container;
  }

  // 傳送下載任務至擴充功能主程式
  function sendDownload(mediaUrl, title, ext = 'mp4') {
    showToast('正在傳送至下載器並開啟任務視窗...', 2500);
    chrome.runtime.sendMessage({
      method: 'open-downloader-for-media',
      item: {
        url: mediaUrl,
        title: title || document.title,
        ext: ext
      }
    });
  }

  // -------------------------------------------------------------
  // 1. Instagram 處理邏輯 (支援貼文、Reels、限時動態 Stories)
  // -------------------------------------------------------------
  function scanInstagram() {
    if (!location.hostname.includes('instagram.com')) return;

    // 處理限時動態 Stories
    const storyContainer = document.querySelector('section[class*="Story"], div[role="dialog"] section, section main');
    if (location.pathname.includes('/stories/') && storyContainer && !storyContainer.querySelector('.social-dl-btn-container')) {
      const btn = createButton('下載此限動', () => {
        const video = storyContainer.querySelector('video');
        const img = storyContainer.querySelector('img[srcset], img[src]');
        if (video && video.src && !video.src.startsWith('blob:')) {
          sendDownload(video.src, `Instagram_限時動態_${Date.now()}`, 'mp4');
        } else if (img && img.src) {
          sendDownload(img.src, `Instagram_限時動態照片_${Date.now()}`, 'jpg');
        } else {
          // 若為 blob 串流，透過當前網址交給背景解析
          chrome.runtime.sendMessage({
            method: 'parse-and-open',
            url: location.href
          });
        }
      });
      storyContainer.style.position = 'relative';
      storyContainer.appendChild(btn);
    }

    // 處理一般貼文與 Reels
    const posts = document.querySelectorAll('article, div[role="dialog"] article');
    posts.forEach(post => {
      if (post.querySelector('.social-dl-btn-container')) return;

      const video = post.querySelector('video');
      const img = post.querySelector('img[srcset]');

      if (video || img) {
        const btn = createButton(video ? '下載 IG 影片/Reels' : '下載 IG 照片', () => {
          if (video && video.src && !video.src.startsWith('blob:')) {
            sendDownload(video.src, `Instagram_影片_${Date.now()}`, 'mp4');
          } else if (img && img.src) {
            sendDownload(img.src, `Instagram_照片_${Date.now()}`, 'jpg');
          } else {
            // 透過貼文連結或當前網址解析
            const link = post.querySelector('a[href*="/p/"], a[href*="/reel/"]');
            const targetUrl = link ? new URL(link.getAttribute('href'), location.origin).href : location.href;
            chrome.runtime.sendMessage({
              method: 'parse-and-open',
              url: targetUrl
            });
          }
        });
        post.style.position = 'relative';
        post.appendChild(btn);
      }
    });
  }

  // -------------------------------------------------------------
  // 2. Facebook 處理邏輯 (支援 Watch、Reels、好友/私人影片)
  // -------------------------------------------------------------
  function scanFacebook() {
    if (!location.hostname.includes('facebook.com')) return;

    const videoWrappers = document.querySelectorAll('div[data-pagelet*="Video"], div[role="article"] div[data-visualcompletion="ignore-dynamic-snippet"], div[role="main"] video');
    videoWrappers.forEach(wrap => {
      const container = wrap.tagName === 'VIDEO' ? wrap.parentElement : wrap;
      if (!container || container.querySelector('.social-dl-btn-container')) return;

      const video = container.querySelector('video') || (wrap.tagName === 'VIDEO' ? wrap : null);
      if (video) {
        const btn = createButton('下載 FB 影片', () => {
          if (video.src && !video.src.startsWith('blob:')) {
            sendDownload(video.src, `Facebook_影片_${Date.now()}`, 'mp4');
          } else {
            // 私人影片或 blob 串流，傳遞當前頁面網址讓帶 Session 之背景端解析
            chrome.runtime.sendMessage({
              method: 'parse-and-open',
              url: location.href
            });
          }
        });
        container.style.position = 'relative';
        container.appendChild(btn);
      }
    });
  }

  // -------------------------------------------------------------
  // 3. TikTok 處理邏輯 (支援高畫質影音)
  // -------------------------------------------------------------
  function scanTikTok() {
    if (!location.hostname.includes('tiktok.com')) return;

    const videoContainers = document.querySelectorAll('div[data-e2e="feed-video"], div[data-e2e="user-post-item"], div[class*="DivVideoWrapper"], div[class*="DivVideoContainer"]');
    videoContainers.forEach(container => {
      if (container.querySelector('.social-dl-btn-container')) return;

      const video = container.querySelector('video');
      if (video) {
        const btn = createButton('下載 TikTok 影音', () => {
          // TikTok 優先使用背景解析以取得無浮水印版 playAddr
          const link = container.querySelector('a[href*="/video/"]');
          const targetUrl = link ? new URL(link.getAttribute('href'), location.origin).href : location.href;
          chrome.runtime.sendMessage({
            method: 'parse-and-open',
            url: targetUrl
          });
        });
        container.style.position = 'relative';
        container.appendChild(btn);
      }
    });
  }

  // 定期掃描與動態監聽 (針對 SPA 單頁面應用與無限捲動)
  function scanAll() {
    scanInstagram();
    scanFacebook();
    scanTikTok();
  }

  // 初次載入與定時掃描
  scanAll();
  const observer = new MutationObserver(() => {
    scanAll();
  });

  observer.observe(document.body, {
    childList: true,
    subtree: true
  });
})();
