/**
 * 社群網頁即時偵測與浮動下載腳本 (Content Script - v46 Debug & Multi-platform Fix)
 * 支援：Facebook、Instagram、TikTok、抖音 (Douyin)
 * 特色：
 * 1. 深度遍歷所有 <video> 與高畫質 <img> 標籤，不受 SPA 框架動態樣式變動影響
 * 2. 精確溯源 Facebook / Instagram 貼文或 Reels 專屬永久網址
 * 3. 即時提供視覺提示 (Toast)，清晰反饋串流解析進度與錯誤原因
 * 4. 支援直接開啟當前分頁嗅探視窗 (應對 blob: 加密串流)
 */

(() => {
  // 建立提示 Toast
  let toastEl = null;
  function showToast(text, duration = 3500) {
    if (!toastEl) {
      toastEl = document.createElement('div');
      toastEl.className = 'social-dl-toast';
      document.body.appendChild(toastEl);
    }
    toastEl.innerHTML = `<span>📥</span> <span>${text}</span>`;
    toastEl.classList.add('show');
    clearTimeout(toastEl._timer);
    toastEl._timer = setTimeout(() => {
      toastEl.classList.remove('show');
    }, duration);
  }

  // 下載圖示 SVG
  const downloadIcon = `
    <svg viewBox="0 0 24 24">
      <path d="M19.35 10.04C18.67 6.59 15.64 4 12 4 9.11 4 6.6 5.64 5.35 8.04 2.34 8.36 0 10.91 0 14c0 3.31 2.69 6 6 6h13c2.76 0 5-2.24 5-5 0-2.64-2.05-4.78-4.65-4.96zM17 13l-5 5-5-5h3V9h4v4h3z"/>
    </svg>
  `;

  // 建立浮動下載按鈕
  function createButton(label, onClick) {
    const container = document.createElement('div');
    container.className = 'social-dl-btn-container';
    
    const btn = document.createElement('button');
    btn.type = 'button';
    btn.className = 'social-dl-btn';
    btn.innerHTML = `${downloadIcon} <span>${label}</span>`;
    btn.addEventListener('click', (e) => {
      e.preventDefault();
      e.stopPropagation();
      onClick();
    });
    
    container.appendChild(btn);
    return container;
  }

  // -------------------------------------------------------------
  // 1. Instagram 處理邏輯 (相容動態牆、Reels、個人主頁與限時動態 Stories)
  // -------------------------------------------------------------
  function scanInstagram() {
    if (!location.hostname.includes('instagram.com')) return;

    // A. 掃描所有影片 (<video>)
    const videos = document.querySelectorAll('video');
    videos.forEach(video => {
      // 尋找影片的最適合容器
      const container = video.closest('div[style*="aspect-ratio"], div._ab6-, div._aa61, article, div[role="dialog"], section, main') || video.parentElement;
      if (!container || container.querySelector('.social-dl-btn-container')) return;

      const isStory = location.pathname.includes('/stories/');
      const label = isStory ? '下載此限動' : '下載 IG 影片/Reels';

      const btn = createButton(label, () => {
        showToast('⏳ 正在取得 IG 串流...', 2500);

        // 若 video.src 為真實 HTTP 串流且非 blob
        if (video.src && !video.src.startsWith('blob:') && video.src.startsWith('http')) {
          chrome.runtime.sendMessage({
            method: 'open-downloader-for-media',
            item: {
              url: video.src,
              title: `Instagram_影片_${Date.now()}`,
              ext: 'mp4'
            }
          });
          showToast('✅ 已成功取得影片串流，正在開啟下載器！', 3000);
          return;
        }

        // 若為 blob 串流，尋找該則貼文的永久網址或限動網址
        let targetUrl = location.href;
        if (!isStory) {
          const postLink = container.closest('article, div[role="dialog"]')?.querySelector('a[href*="/p/"], a[href*="/reel/"]');
          if (postLink) {
            targetUrl = new URL(postLink.getAttribute('href'), location.origin).href;
          }
        }

        chrome.runtime.sendMessage({
          method: 'parse-and-open',
          url: targetUrl
        }, res => {
          if (res && res.error) {
            showToast('⚠️ 解析失敗：' + res.error, 4500);
          } else {
            showToast('✅ 正在透過瀏覽器登入憑證解析高畫質串流並開啟下載器...', 3000);
          }
        });
      });

      // 確保按鈕定位正確
      if (getComputedStyle(container).position === 'static') {
        container.style.position = 'relative';
      }
      container.appendChild(btn);
    });

    // B. 掃描高解析度照片 (排除小頭貼與圖標)
    const images = document.querySelectorAll('article img[srcset], div[role="dialog"] img[srcset], section img[srcset]');
    images.forEach(img => {
      if (img.width < 180 || img.height < 180) return;
      const container = img.closest('div._aagv, div[style*="aspect-ratio"], article, div[role="dialog"]') || img.parentElement;
      if (!container || container.querySelector('.social-dl-btn-container') || container.querySelector('video')) return;

      const btn = createButton('下載 IG 照片', () => {
        // 從 srcset 抓取最高解析度版本
        let src = img.src;
        if (img.srcset) {
          const candidates = img.srcset.split(',').map(s => s.trim().split(' '));
          if (candidates.length > 0) {
            src = candidates[candidates.length - 1][0] || img.src;
          }
        }

        chrome.runtime.sendMessage({
          method: 'open-downloader-for-media',
          item: {
            url: src,
            title: `Instagram_照片_${Date.now()}`,
            ext: 'jpg'
          }
        });
        showToast('✅ 已將高畫質照片傳送至下載器！', 2500);
      });

      if (getComputedStyle(container).position === 'static') {
        container.style.position = 'relative';
      }
      container.appendChild(btn);
    });
  }

  // -------------------------------------------------------------
  // 2. Facebook 處理邏輯 (相容 Watch、動態牆 Feed、Reels 與好友影片)
  // -------------------------------------------------------------
  function scanFacebook() {
    if (!location.hostname.includes('facebook.com')) return;

    const videos = document.querySelectorAll('video');
    videos.forEach(video => {
      const container = video.closest('div[data-pagelet*="Video"], div[data-pagelet*="FeedUnit"], div[role="article"], div[data-visualcompletion], div[role="main"]') || video.parentElement;
      if (!container || container.querySelector('.social-dl-btn-container')) return;

      const btn = createButton('下載 FB 影片', () => {
        showToast('⏳ 正在檢查 Facebook 串流與播放源...', 2500);

        // 1. 若 video.src 為真實 HTTP 網址且非 blob
        if (video.src && !video.src.startsWith('blob:') && video.src.startsWith('http')) {
          chrome.runtime.sendMessage({
            method: 'open-downloader-for-media',
            item: {
              url: video.src,
              title: `Facebook_影片_${Date.now()}`,
              ext: 'mp4'
            }
          });
          showToast('✅ 已取得影片串流，正在啟動下載視窗！', 3000);
          return;
        }

        // 2. 尋找貼文/Reels/Watch 永久網址
        let targetUrl = '';
        if (location.pathname.includes('/watch') || location.pathname.includes('/reel/') || location.pathname.includes('/videos/')) {
          targetUrl = location.href;
        } else {
          // 從貼文容器向上尋找連結
          const link = container.closest('div[role="article"], div[data-pagelet*="Feed"], div[data-pagelet*="Video"]')
            ?.querySelector('a[href*="/videos/"], a[href*="/watch/"], a[href*="/reel/"], a[href*="/posts/"], a[href*="permalink"]');
          if (link) {
            targetUrl = new URL(link.getAttribute('href'), location.origin).href;
          }
        }

        if (targetUrl) {
          showToast('🔍 偵測到影片永久網址，正在使用登入憑證解析高畫質串流...', 3500);
          chrome.runtime.sendMessage({
            method: 'parse-and-open',
            url: targetUrl
          }, res => {
            if (res && res.error) {
              // 若解析失敗，開啟當前分頁嗅探視窗作為備用
              showToast('⚠️ 背景解析失敗，改為直接嗅探當前分頁已載入的串流...', 3000);
              chrome.runtime.sendMessage({ method: 'open-downloader-current-tab' });
            }
          });
        } else {
          // 若在動態時報快速預覽且未找到永久連結，直接開啟本分頁的媒體嗅探視窗！
          showToast('💡 提示：正在為您開啟當前分頁嗅探下載器，抓取已載入之串流片段...', 3500);
          chrome.runtime.sendMessage({ method: 'open-downloader-current-tab' });
        }
      });

      if (getComputedStyle(container).position === 'static') {
        container.style.position = 'relative';
      }
      container.appendChild(btn);
    });
  }

  // -------------------------------------------------------------
  // 3. TikTok 與 抖音 (Douyin) 處理邏輯
  // -------------------------------------------------------------
  function scanTikTokAndDouyin() {
    const isTikTok = location.hostname.includes('tiktok.com');
    const isDouyin = location.hostname.includes('douyin.com');
    if (!isTikTok && !isDouyin) return;

    const videos = document.querySelectorAll('video');
    videos.forEach(video => {
      const container = video.closest('div[data-e2e="feed-video"], div[class*="DivVideoWrapper"], div[class*="xgplayer"], div[data-e2e="user-post-item"]') || video.parentElement;
      if (!container || container.querySelector('.social-dl-btn-container')) return;

      const label = isDouyin ? '下載抖音影音' : '下載 TikTok 影音';
      const btn = createButton(label, () => {
        showToast(`⏳ 正在獲取 ${isDouyin ? '抖音' : 'TikTok'} 無浮水印串流...`, 2500);

        // 優先嘗試直連影片
        if (video.src && !video.src.startsWith('blob:') && video.src.startsWith('http')) {
          chrome.runtime.sendMessage({
            method: 'open-downloader-for-media',
            item: {
              url: video.src,
              title: `${isDouyin ? '抖音' : 'TikTok'}_影音_${Date.now()}`,
              ext: 'mp4'
            }
          });
          showToast('✅ 已成功取得影片串流，正在開啟下載器！', 3000);
          return;
        }

        // 尋找影片永久連結
        let targetUrl = location.href;
        const link = container.querySelector('a[href*="/video/"]');
        if (link) {
          targetUrl = new URL(link.getAttribute('href'), location.origin).href;
        }

        chrome.runtime.sendMessage({
          method: 'parse-and-open',
          url: targetUrl
        }, res => {
          if (res && res.error) {
            showToast('⚠️ 解析無浮水印版本失敗，改為開啟分頁串流嗅探器...', 3000);
            chrome.runtime.sendMessage({ method: 'open-downloader-current-tab' });
          } else {
            showToast('✅ 正在透過登入憑證解析無浮水印串流...', 3000);
          }
        });
      });

      if (getComputedStyle(container).position === 'static') {
        container.style.position = 'relative';
      }
      container.appendChild(btn);
    });
  }

  // -------------------------------------------------------------
  // 4. 定時與變更掃描 (針對 SPA 單頁面應用與無限捲動)
  // -------------------------------------------------------------
  function scanAll() {
    scanInstagram();
    scanFacebook();
    scanTikTokAndDouyin();
  }

  // 啟動初次掃描
  scanAll();

  // 監聽網頁 DOM 節點變化
  const observer = new MutationObserver(() => {
    scanAll();
  });

  observer.observe(document.body, {
    childList: true,
    subtree: true
  });
})();
