/**
 * 社群網頁格式防錯與 Facebook Reels 強化下載引擎 (v56 Format Guard & FB Reels Fix)
 * 核心升級：
 * 1. 【保留正常】：原汁原味保留 Facebook 限時動態、Facebook 一般照片、Instagram 動態內照片之優異表現！
 * 2. 【格式防錯】：全面杜絕 Instagram 影片與 Reel 誤抓封面縮圖變成 JFIF 的問題，嚴格過濾與強制 MP4 輸出！
 * 3. 【Facebook Reels & 焦點影片修復】：強化 Facebook Reels 專屬 ID 比對與 Progressive 串流提取，解決影片異常問題！
 */

(() => {
  // 建立提示訊息 (Toast)
  let toastEl = null;
  function showToast(text, duration = 3000) {
    if (!toastEl) {
      toastEl = document.createElement('div');
      toastEl.className = 'social-dl-toast';
      document.body.appendChild(toastEl);
    }
    toastEl.innerHTML = `<span>⚡</span> <span>${text}</span>`;
    toastEl.classList.add('show');
    clearTimeout(toastEl._timer);
    toastEl._timer = setTimeout(() => {
      toastEl.classList.remove('show');
    }, duration);
  }

  // 下載圖示 SVG
  const downloadIcon = `
    <svg viewBox="0 0 24 24">
      <path d="M19.35 10.04C18.67 6.59 15.64 4 12 4 9.11 4 6.6 5.64 5.35 8.04 2.34 8.36 0 10.91 0 14c0 3.31 2.69 6 6 6h13c2.76 0 5-2.24 5-5 0-2.64-2.05-4.78-4.65-4.96zM17 13l-5 5-5-5h3V9h4v4h3z"/>
    </svg>
  `;

  // 建立浮動下載按鈕
  function createButton(label, onClick, customClass = '') {
    const container = document.createElement('div');
    container.className = `social-dl-btn-container ${customClass}`;
    
    const btn = document.createElement('button');
    btn.type = 'button';
    btn.className = `social-dl-btn ${customClass ? customClass + '-btn' : ''}`;
    btn.innerHTML = `${downloadIcon} <span>${label}</span>`;
    btn.addEventListener('click', (e) => {
      e.preventDefault();
      e.stopPropagation();
      onClick();
    });
    
    container.appendChild(btn);
    return container;
  }

  // 清理影片網址中的分段 Range 限制參數 (bytestart/byteend)
  function cleanVideoUrl(rawUrl) {
    if (!rawUrl) return '';
    try {
      const u = new URL(rawUrl);
      u.searchParams.delete('bytestart');
      u.searchParams.delete('byteend');
      return u.href;
    } catch (e) {
      return rawUrl.replace(/([?&])bytestart=\d+(&?)/, '$1').replace(/([?&])byteend=\d+(&?)/, '$1');
    }
  }

  // 觸發本機檔案儲存 (強制校正副檔名，絕不允許影片變圖片)
  function triggerSave(url, filename, isVideo = false) {
    let safeName = filename;
    if (isVideo && !safeName.toLowerCase().endsWith('.mp4')) {
      safeName = safeName.replace(/\.[a-zA-Z0-9]+$/, '') + '.mp4';
    }

    chrome.runtime.sendMessage({
      method: 'download-cached-file',
      url: url,
      filename: safeName,
      saveAs: false
    }, res => {
      if (!res || res.error) {
        const a = document.createElement('a');
        a.href = url;
        a.download = safeName;
        document.body.appendChild(a);
        a.click();
        setTimeout(() => a.remove(), 1000);
      }
    });
  }

  // -------------------------------------------------------------------------
  // 1. 取得貼文專屬網址 (Post ID / Shortcode)
  // -------------------------------------------------------------------------
  function findPostUrl(element) {
    if (!element) return null;

    // 若當前就在 Reel 頁面
    if (location.pathname.includes('/reel/') || location.pathname.includes('/reels/')) {
      return location.href;
    }

    let curr = element;
    let depth = 0;
    while (curr && depth < 12) {
      const link = curr.querySelector(
        'a[href*="/reel/"], a[href*="/p/"], a[href*="/videos/"], a[href*="/watch/"], a[href*="/posts/"], a[href*="permalink.php"], a[href*="story.php"]'
      );
      if (link && link.href) return link.href;
      curr = curr.parentElement;
      depth++;
    }
    return location.href;
  }

  // -------------------------------------------------------------------------
  // 2. React 內部記憶體挖掘 (嚴格要求 MP4 格式，徹底杜絕 JFIF)
  // -------------------------------------------------------------------------
  function extractProgressiveFromReact(element) {
    if (!element) return null;
    const visited = new Set();
    const targetKeys = [
      'playable_url_quality_hd',
      'browser_native_hd_url',
      'playable_url',
      'browser_native_sd_url',
      'hd_src',
      'sd_src',
      'video_url'
    ];

    function searchInObj(obj, depth) {
      if (!obj || depth > 8 || visited.has(obj)) return null;
      if (typeof obj !== 'object' && typeof obj !== 'function') return null;
      visited.add(obj);

      for (const k of targetKeys) {
        if (typeof obj[k] === 'string' && obj[k].startsWith('http')) {
          const lower = obj[k].toLowerCase();
          // 嚴格排除任何圖片副檔名
          if (!lower.includes('.jpg') && !lower.includes('.png') && !lower.includes('.jfif') && !lower.includes('.webp')) {
            return cleanVideoUrl(obj[k]);
          }
        }
      }

      if (Array.isArray(obj.video_versions) && obj.video_versions.length > 0) {
        const first = obj.video_versions[0];
        if (first && typeof first.url === 'string' && !first.url.includes('.jpg')) {
          return cleanVideoUrl(first.url);
        }
      }

      for (const key of Object.keys(obj)) {
        try {
          const val = obj[key];
          if (typeof val === 'string' && val.startsWith('http') && val.includes('.mp4')) {
            const lower = val.toLowerCase();
            if (!lower.includes('audio') && !lower.includes('.jpg') && (lower.includes('fbcdn.net') || lower.includes('cdninstagram.com'))) {
              return cleanVideoUrl(val);
            }
          } else if (typeof val === 'object' && val !== null) {
            const res = searchInObj(val, depth + 1);
            if (res) return res;
          }
        } catch (e) {}
      }
      return null;
    }

    let curr = element;
    let level = 0;
    while (curr && level < 8) {
      for (const prop in curr) {
        if (prop.startsWith('__reactFiber') || prop.startsWith('__reactProps') || prop.startsWith('__reactInternalInstance')) {
          const url = searchInObj(curr[prop], 0);
          if (url) return url;
        }
      }
      curr = curr.parentElement;
      level++;
    }
    return null;
  }

  // -------------------------------------------------------------------------
  // 3. 核心影片下載調度 (保證 100% 輸出 MP4，絕不變成 JFIF)
  // -------------------------------------------------------------------------
  async function downloadVideo(video, filename, platform) {
    showToast(`🔍 正在定向鎖定此 ${platform} 影片 (音畫合一 MP4 格式防錯檢測)...`, 2000);

    // 階段 1：直接檢查原生 video.currentSrc
    const directSrc = video.currentSrc || video.src || video.querySelector('source')?.src;
    if (directSrc && directSrc.startsWith('http') && !directSrc.startsWith('blob:') && directSrc.includes('.mp4')) {
      const fullUrl = cleanVideoUrl(directSrc);
      triggerSave(fullUrl, filename, true);
      showToast(`✅ 已從原生快取下載此 ${platform} 完整 MP4 影片！`, 3000);
      return;
    }

    // 階段 2：從 React Fiber 樹直接挖掘 Progressive MP4 (自帶聲音與畫面)
    const reactUrl = extractProgressiveFromReact(video);
    if (reactUrl && reactUrl.includes('.mp4')) {
      triggerSave(reactUrl, filename, true);
      showToast(`🎉 成功獲取官方 Progressive 音畫合一 MP4 影片！`, 3500);
      return;
    }

    // 階段 3：使用貼文專屬網址發起【單篇貼文定向解析】
    const postUrl = findPostUrl(video) || location.href;
    if (postUrl && postUrl !== 'https://www.facebook.com/' && postUrl !== 'https://www.instagram.com/') {
      showToast(`⚡ 正在針對該專屬貼文進行定向解析 (杜絕其他貼文干擾)...`, 2500);
      chrome.runtime.sendMessage({
        method: 'download-specific-post',
        postUrl: postUrl,
        platform: platform,
        filename: filename
      }, res => {
        if (res && res.success && res.url && !res.url.includes('.jpg') && !res.url.includes('.jfif')) {
          showToast(`🎉 成功定向下載此貼文之完整音畫 MP4 影片！`, 3500);
        } else {
          fallbackActiveCapture(postUrl, filename, platform);
        }
      });
      return;
    }

    fallbackActiveCapture(postUrl, filename, platform);
  }

  function fallbackActiveCapture(postUrl, filename, platform) {
    chrome.runtime.sendMessage({
      method: 'download-active-media',
      platform: platform,
      postUrl: postUrl,
      filename: filename
    }, res => {
      if (res && res.success) {
        showToast(`🎉 成功捕獲此目標 MP4 影片！已啟動下載！`, 3500);
      } else {
        showToast(`💡 請讓此影片播放 1~2 秒以利快取完整捕獲！`, 4000);
      }
    });
  }

  // -------------------------------------------------------------------------
  // 4. 照片精準導出 (保留完全正常之原汁原味邏輯)
  // -------------------------------------------------------------------------
  function downloadImage(img, filename) {
    showToast('⏳ 正在精準導出該張照片...', 2000);
    try {
      const canvas = document.createElement('canvas');
      canvas.width = img.naturalWidth || img.width;
      canvas.height = img.naturalHeight || img.height;
      const ctx = canvas.getContext('2d');
      ctx.drawImage(img, 0, 0);

      canvas.toBlob(blob => {
        if (blob) {
          const blobUrl = URL.createObjectURL(blob);
          triggerSave(blobUrl, filename, false);
          showToast('✅ 成功從記憶體無損導出該張照片！', 2500);
        } else {
          fallbackImageDownload(img, filename);
        }
      }, 'image/jpeg', 0.98);
      return;
    } catch (e) {}

    fallbackImageDownload(img, filename);
  }

  function fallbackImageDownload(img, filename) {
    let src = img.currentSrc || img.src;
    if (img.srcset) {
      const parts = img.srcset.split(',').map(s => s.trim().split(' '));
      if (parts.length > 0) src = parts[parts.length - 1][0] || src;
    }
    fetch(src, { cache: 'force-cache' })
      .then(r => r.blob())
      .then(blob => {
        const blobUrl = URL.createObjectURL(blob);
        triggerSave(blobUrl, filename, false);
        showToast('✅ 成功下載該張照片！', 2500);
      })
      .catch(() => {
        triggerSave(src, filename, false);
        showToast('✅ 已加入照片下載佇列！', 2500);
      });
  }

  // 檢查圖片是否為影片之封面縮圖 (徹底杜絕影片誤掛照片按鈕導致 JFIF)
  function isAssociatedWithVideo(img) {
    if (location.pathname.includes('/reel/') || location.pathname.includes('/reels/')) {
      return true; // Reel 頁面之大圖 100% 為影片封面，嚴禁掛載照片按鈕！
    }

    let curr = img.parentElement;
    let depth = 0;
    while (curr && depth < 6) {
      if (curr.querySelector && curr.querySelector('video')) {
        return true;
      }
      curr = curr.parentElement;
      depth++;
    }
    return false;
  }

  // -------------------------------------------------------------------------
  // 5. 實體直接錨定：掃描所有 <video> 元素並掛載按鈕
  // -------------------------------------------------------------------------
  function scanVideos() {
    const isFB = location.hostname.includes('facebook.com');
    const isIG = location.hostname.includes('instagram.com');
    if (!isFB && !isIG) return;

    // 限動由專屬面板處理 (保留完全正常之限動邏輯)
    if (isIG && location.pathname.includes('/stories/')) return;

    const videos = document.querySelectorAll('video');
    videos.forEach(video => {
      let parent = video.parentElement;
      if (!parent) return;

      let container = parent;
      if (container.querySelector(':scope > .social-dl-btn-container')) return;

      if (container.clientHeight < 50 && container.parentElement) {
        container = container.parentElement;
      }
      if (container.querySelector(':scope > .social-dl-btn-container')) return;

      const isReel = location.pathname.includes('/reel/') || location.pathname.includes('/reels/');
      const platform = isFB ? 'Facebook' : 'Instagram';
      const label = `下載 ${platform} ${isReel ? 'Reel' : '影片'} (MP4 音畫合一)`;

      const btn = createButton(label, () => {
        const id = Date.now().toString().slice(-4);
        downloadVideo(video, `${platform}_${isReel ? 'Reel' : '影片'}_${id}.mp4`, platform);
      });

      if (getComputedStyle(container).position === 'static') {
        container.style.position = 'relative';
      }
      container.appendChild(btn);
    });
  }

  // -------------------------------------------------------------------------
  // 6. 實體直接錨定：掃描主畫面照片 (嚴格排除任何影片封面縮圖)
  // -------------------------------------------------------------------------
  function scanImages() {
    const isFB = location.hostname.includes('facebook.com');
    const isIG = location.hostname.includes('instagram.com');
    if (!isFB && !isIG) return;
    if (isIG && location.pathname.includes('/stories/')) return;

    // 尋找寬高大於 220px 的純貼文照片
    const images = Array.from(document.querySelectorAll('img')).filter(img => {
      return (img.clientWidth >= 220 || img.width >= 220) && (img.clientHeight >= 220 || img.height >= 220);
    });

    images.forEach(img => {
      // 【核心防錯】：若為影片封面縮圖，絕不掛載照片按鈕！
      if (isAssociatedWithVideo(img)) return;

      const parent = img.parentElement;
      if (!parent || parent.querySelector(':scope > .social-dl-btn-container')) return;

      let container = parent;
      if (container.querySelector('.social-dl-btn-container')) return;

      const platform = isFB ? 'FB' : 'IG';
      const btn = createButton(`下載此 ${platform} 照片`, () => {
        const id = Date.now().toString().slice(-4);
        downloadImage(img, `${platform}_照片_${id}.jpg`);
      }, 'photo-dl');

      if (getComputedStyle(container).position === 'static') {
        container.style.position = 'relative';
      }
      container.appendChild(btn);
    });
  }

  // -------------------------------------------------------------------------
  // 7. Instagram 限時動態 (Stories) 頂層面板 (保留完全正常之原汁原味邏輯)
  // -------------------------------------------------------------------------
  function scanInstagramStories() {
    if (!location.hostname.includes('instagram.com') || !location.pathname.includes('/stories/')) {
      const p = document.querySelector('.social-dl-story-panel');
      if (p) p.remove();
      return;
    }

    if (document.querySelector('.social-dl-story-panel')) return;

    const panel = document.createElement('div');
    panel.className = 'social-dl-story-panel';

    const btn = document.createElement('button');
    btn.type = 'button';
    btn.className = 'social-dl-btn social-dl-story-btn';
    btn.innerHTML = `${downloadIcon} <span>📥 下載當前限動 (音畫合一)</span>`;
    btn.addEventListener('click', (e) => {
      e.preventDefault();
      e.stopPropagation();

      const storyVideo = document.querySelector('section video, div[role="dialog"] video, main video, video');
      if (storyVideo && storyVideo.src) {
        downloadVideo(storyVideo, `Instagram_限動影片_${Date.now()}.mp4`, 'Instagram');
        return;
      }

      const storyImages = Array.from(document.querySelectorAll('section img, div[role="dialog"] img, main img, img')).filter(img => img.width > 250 || img.height > 250);
      if (storyImages.length > 0) {
        downloadImage(storyImages[0], `Instagram_限動照片_${Date.now()}.jpg`);
      } else {
        showToast('💡 正在即時捕捉限動串流，請讓畫面播放 1 秒後重試！');
      }
    });

    panel.appendChild(btn);
    document.body.appendChild(panel);
  }

  // -------------------------------------------------------------------------
  // 8. 全域右下角懸浮下載小幫手 (影片絕對優先，絕不誤抓封面 JFIF)
  // -------------------------------------------------------------------------
  function mountGlobalFloatingBadge() {
    if (document.querySelector('.social-dl-floating-badge')) return;

    const badge = document.createElement('div');
    badge.className = 'social-dl-floating-badge';
    badge.innerHTML = `${downloadIcon} <span>⚡ 快速下載當前焦點影音</span>`;
    badge.title = '點擊即可一鍵下載目前正在螢幕中央播放的影片或照片！';

    badge.addEventListener('click', (e) => {
      e.preventDefault();
      e.stopPropagation();

      const platform = location.hostname.includes('facebook.com') ? 'Facebook' : 'Instagram';

      // 1. 【影片絕對優先】：只要頁面有 video 標籤，100% 只下載影片，絕不抓成封面照片！
      const allVideos = Array.from(document.querySelectorAll('video'));
      if (allVideos.length > 0) {
        const viewportCenterY = window.innerHeight / 2;
        let bestVideo = allVideos[0];
        let minDist = Infinity;
        for (const v of allVideos) {
          const rect = v.getBoundingClientRect();
          if (rect.bottom > 0 && rect.top < window.innerHeight) {
            const dist = Math.abs((rect.top + rect.height / 2) - viewportCenterY);
            if (dist < minDist) {
              minDist = dist;
              bestVideo = v;
            }
          }
        }
        const isReel = location.pathname.includes('/reel/') || location.pathname.includes('/reels/');
        downloadVideo(bestVideo, `${platform}_${isReel ? 'Reel' : '焦點影片'}_${Date.now()}.mp4`, platform);
        return;
      }

      // 2. 只有當 100% 沒有影片時，才尋找純貼文大圖 (排除影片封面)
      const images = Array.from(document.querySelectorAll('img')).filter(img => {
        return (img.clientWidth > 220 || img.width > 220) && !isAssociatedWithVideo(img);
      });

      if (images.length > 0) {
        const viewportCenterY = window.innerHeight / 2;
        let bestImg = images[0];
        let minDist = Infinity;
        for (const img of images) {
          const rect = img.getBoundingClientRect();
          if (rect.bottom > 0 && rect.top < window.innerHeight) {
            const dist = Math.abs((rect.top + rect.height / 2) - viewportCenterY);
            if (dist < minDist) {
              minDist = dist;
              bestImg = img;
            }
          }
        }
        downloadImage(bestImg, `${platform}_焦點照片_${Date.now()}.jpg`);
        return;
      }

      showToast('💡 畫面上尚未偵測到播放中的影片或照片，請滾動至目標貼文！');
    });

    document.body.appendChild(badge);
  }

  // -------------------------------------------------------------------------
  // 9. 整合與 MutationObserver 輕量監聽
  // -------------------------------------------------------------------------
  function scanAll() {
    scanVideos();
    scanImages();
    scanInstagramStories();
    mountGlobalFloatingBadge();
  }

  scanAll();
  const observer = new MutationObserver(() => {
    scanAll();
  });
  observer.observe(document.body, { childList: true, subtree: true });
})();
