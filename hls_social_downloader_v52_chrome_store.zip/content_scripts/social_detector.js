/**
 * 社群網頁快取優先與 DOM 精準目標鎖定架構 (Content Script - v52 Precision DOM Architecture)
 * 專注平台：Facebook、Instagram (已依要求停用 TikTok/抖音 以確保原站播放順暢)
 * 核心機制：
 * 1. 深度解析點擊按鈕所屬之貼文 DOM 容器與 React 內部屬性 (__reactProps/__reactFiber)。
 * 2. 精準提取該貼文專屬之高畫質影片串流 (HD/SD MP4)，杜絕全頁盲抓與抓錯其他貼文或廣告之問題。
 * 3. 照片精準下載：直接鎖定所選 <img> 元素之最高解析度來源，支援 Canvas 畫布直出與 Chrome 快取提取。
 */

(() => {
  // 建立提示訊息 (Toast)
  let toastEl = null;
  function showToast(text, duration = 3000) {
    if (!toastEl) {
      toastEl = document.createElement('div');
      toastEl.className = 'social-dl-toast';
      document.body.appendChild(toastEl);
    }
    toastEl.innerHTML = `<span>⚡</span> <span>${text}</span>`;
    toastEl.classList.add('show');
    clearTimeout(toastEl._timer);
    toastEl._timer = setTimeout(() => {
      toastEl.classList.remove('show');
    }, duration);
  }

  // 下載圖示 SVG
  const downloadIcon = `
    <svg viewBox="0 0 24 24">
      <path d="M19.35 10.04C18.67 6.59 15.64 4 12 4 9.11 4 6.6 5.64 5.35 8.04 2.34 8.36 0 10.91 0 14c0 3.31 2.69 6 6 6h13c2.76 0 5-2.24 5-5 0-2.64-2.05-4.78-4.65-4.96zM17 13l-5 5-5-5h3V9h4v4h3z"/>
    </svg>
  `;

  // 建立浮動下載按鈕
  function createButton(label, onClick) {
    const container = document.createElement('div');
    container.className = 'social-dl-btn-container';
    
    const btn = document.createElement('button');
    btn.type = 'button';
    btn.className = 'social-dl-btn';
    btn.innerHTML = `${downloadIcon} <span>${label}</span>`;
    btn.addEventListener('click', (e) => {
      e.preventDefault();
      e.stopPropagation();
      onClick();
    });
    
    container.appendChild(btn);
    return container;
  }

  // 清理影片網址中的分段 Range 限制參數 (bytestart/byteend)，確保下載為完整檔案
  function cleanVideoUrl(rawUrl) {
    if (!rawUrl) return '';
    try {
      const u = new URL(rawUrl);
      u.searchParams.delete('bytestart');
      u.searchParams.delete('byteend');
      return u.href;
    } catch (e) {
      return rawUrl.replace(/([?&])bytestart=\d+(&?)/, '$1').replace(/([?&])byteend=\d+(&?)/, '$1');
    }
  }

  // 觸發本機檔案儲存 (優先呼叫擴充套件 Downloads API，備用 a[download])
  function triggerSave(url, filename) {
    chrome.runtime.sendMessage({
      method: 'download-cached-file',
      url: url,
      filename: filename,
      saveAs: false
    }, res => {
      if (!res || res.error) {
        const a = document.createElement('a');
        a.href = url;
        a.download = filename;
        document.body.appendChild(a);
        a.click();
        setTimeout(() => a.remove(), 1000);
      }
    });
  }

  // -------------------------------------------------------------------------
  // 1. React 內部屬性深度挖掘 (從目標 DOM 節點反查 Facebook/Instagram 原始影片網址)
  // -------------------------------------------------------------------------
  function extractMediaUrlFromReact(element) {
    if (!element) return null;

    const visited = new Set();
    const targetKeys = [
      'playable_url_quality_hd',
      'playable_url',
      'browser_native_hd_url',
      'browser_native_sd_url',
      'video_url',
      'display_url'
    ];

    function searchInObj(obj, depth) {
      if (!obj || depth > 6 || visited.has(obj)) return null;
      if (typeof obj !== 'object' && typeof obj !== 'function') return null;
      visited.add(obj);

      // 直接檢查目標關鍵屬性
      for (const k of targetKeys) {
        if (typeof obj[k] === 'string' && obj[k].startsWith('http')) {
          return cleanVideoUrl(obj[k]);
        }
      }

      // 檢查 Instagram 常見的 video_versions 陣列
      if (Array.isArray(obj.video_versions) && obj.video_versions.length > 0) {
        const first = obj.video_versions[0];
        if (first && typeof first.url === 'string') {
          return cleanVideoUrl(first.url);
        }
      }

      // 檢查屬性值內是否直接含有 fbcdn 或 cdninstagram 的 mp4 直連
      for (const key of Object.keys(obj)) {
        try {
          const val = obj[key];
          if (typeof val === 'string' && val.startsWith('http') && val.includes('.mp4')) {
            if (val.includes('fbcdn.net') || val.includes('cdninstagram.com')) {
              return cleanVideoUrl(val);
            }
          } else if (typeof val === 'object' && val !== null) {
            const res = searchInObj(val, depth + 1);
            if (res) return res;
          }
        } catch (e) {
          // 略過無法存取的內部屬性
        }
      }
      return null;
    }

    // 沿著 DOM 向上搜尋最多 6 層父容器
    let curr = element;
    let level = 0;
    while (curr && level < 6) {
      for (const prop in curr) {
        if (prop.startsWith('__reactFiber') || prop.startsWith('__reactProps') || prop.startsWith('__reactInternalInstance')) {
          const url = searchInObj(curr[prop], 0);
          if (url) return url;
        }
      }
      curr = curr.parentElement;
      level++;
    }

    return null;
  }

  // 取得目標貼文的永久專屬連結 (Permalink)
  function getPostPermalink(container) {
    if (!container) return null;
    // 尋找貼文連結：FB 的 watch/reel/videos/posts；IG 的 /p/ 或 /reel/
    const linkEl = container.querySelector(
      'a[href*="/reel/"], a[href*="/p/"], a[href*="/videos/"], a[href*="/watch/"], a[href*="/posts/"], a[href*="permalink.php"]'
    );
    if (linkEl && linkEl.href) {
      return linkEl.href;
    }
    return null;
  }

  // -------------------------------------------------------------------------
  // 2. 照片精準下載 (指定照片節點 <img>)
  // -------------------------------------------------------------------------
  async function exportSpecificImage(img, filename) {
    showToast('⏳ 正在精準提取此張照片...', 2000);

    // 途徑 A：Canvas 畫布直出 (記憶體無損複製)
    try {
      const canvas = document.createElement('canvas');
      canvas.width = img.naturalWidth || img.width;
      canvas.height = img.naturalHeight || img.height;
      const ctx = canvas.getContext('2d');
      ctx.drawImage(img, 0, 0);

      canvas.toBlob(blob => {
        if (blob) {
          const blobUrl = URL.createObjectURL(blob);
          triggerSave(blobUrl, filename);
          showToast('✅ 成功從本機記憶體導出該張照片！', 2500);
        } else {
          fallbackFetchImage(img, filename);
        }
      }, 'image/jpeg', 0.98);
      return;
    } catch (e) {
      // 跨網域 Canvas 限制，改走途徑 B
    }

    fallbackFetchImage(img, filename);
  }

  function fallbackFetchImage(img, filename) {
    let src = img.currentSrc || img.src;
    if (img.srcset) {
      const parts = img.srcset.split(',').map(s => s.trim().split(' '));
      if (parts.length > 0) {
        src = parts[parts.length - 1][0] || src;
      }
    }

    fetch(src, { cache: 'force-cache' })
      .then(r => r.blob())
      .then(blob => {
        const blobUrl = URL.createObjectURL(blob);
        triggerSave(blobUrl, filename);
        showToast('✅ 成功從 Chrome 快取下載該張照片！', 2500);
      })
      .catch(() => {
        triggerSave(src, filename);
        showToast('✅ 已啟動該張照片下載！', 2500);
      });
  }

  // -------------------------------------------------------------------------
  // 3. 影片精準下載 (鎖定特定影片節點 <video>)
  // -------------------------------------------------------------------------
  async function exportSpecificVideo(video, container, filename, platform) {
    showToast(`🔍 正在精準鎖定並解析此 ${platform} 影片...`, 2000);

    // 步驟 1：優先檢查 <video> 原生 src 或 source 標籤
    const directSrc = video.currentSrc || video.src || video.querySelector('source')?.src;
    if (directSrc && directSrc.startsWith('http') && !directSrc.startsWith('blob:')) {
      const fullUrl = cleanVideoUrl(directSrc);
      triggerSave(fullUrl, filename);
      showToast(`✅ 已從原生快取直接啟動此 ${platform} 影片下載！`, 3000);
      return;
    }

    // 步驟 2：從該節點及其父層 React 元件深度提取該影片的 HD/SD 直連串流
    const reactUrl = extractMediaUrlFromReact(video);
    if (reactUrl) {
      triggerSave(reactUrl, filename);
      showToast(`🎉 成功從 React 核心鎖定並下載此 ${platform} 專屬影片！`, 3500);
      return;
    }

    // 步驟 3：取得該貼文的專屬網址
    const postUrl = getPostPermalink(container) || location.href;

    // 步驟 4：若為 Blob 串流，向擴充套件傳遞專屬貼文網址與精準下載指令
    showToast(`⚡ 正在從 Chrome 網路快取擷取該目標影片...`, 2000);
    chrome.runtime.sendMessage({
      method: 'download-active-media',
      platform: platform,
      postUrl: postUrl,
      filename: filename
    }, res => {
      if (res && res.success) {
        showToast(`🎉 成功捕獲此目標影片！已啟動下載！`, 3500);
      } else {
        // 如果背景暫未捕捉到，嘗試以該貼文的專有網址進行背景解析
        if (postUrl && postUrl !== location.href) {
          showToast(`⚡ 正在針對該貼文進行精準背景解析...`, 2500);
          chrome.runtime.sendMessage({
            method: 'parse-and-open',
            url: postUrl
          }, parseRes => {
            if (parseRes && parseRes.success) {
              showToast(`✅ 已精準解析該貼文影片並載入下載器！`, 3500);
            } else {
              const msg = res?.error || '請讓此特定影片播放 1~2 秒以利快取完整捕獲！';
              showToast(`💡 ${msg}`, 4000);
            }
          });
        } else {
          const msg = res?.error || '請讓此特定影片播放 1~2 秒以利快取完整捕獲！';
          showToast(`💡 ${msg}`, 4000);
        }
      }
    });
  }

  // -------------------------------------------------------------------------
  // 4. Instagram 掃描與掛載 (精準定位貼文與限時動態)
  // -------------------------------------------------------------------------
  function scanInstagram() {
    if (!location.hostname.includes('instagram.com')) return;

    // A. 影片掃描
    const videos = document.querySelectorAll('video');
    videos.forEach(video => {
      // 鎖定該影片所屬的獨立容器 (貼文框、彈出對話框、限動框)
      const container = video.closest('article, div[role="dialog"], div._ab6-, div._aa61, div[style*="aspect-ratio"], section') || video.parentElement;
      if (!container || container.querySelector('.social-dl-btn-container')) return;

      const isStory = location.pathname.includes('/stories/');
      const label = isStory ? '快取下載此限動' : '快取下載此影片';

      const btn = createButton(label, () => {
        const id = Date.now().toString().slice(-4);
        exportSpecificVideo(video, container, `Instagram_${isStory ? '限動' : '影片'}_${id}.mp4`, 'Instagram');
      });

      if (getComputedStyle(container).position === 'static') {
        container.style.position = 'relative';
      }
      container.appendChild(btn);
    });

    // B. 照片掃描
    const images = document.querySelectorAll('article img[srcset], div[role="dialog"] img[srcset], section img[srcset]');
    images.forEach(img => {
      // 排除極小頭像與圖標
      if (img.width < 180 || img.height < 180) return;
      const container = img.closest('div._aagv, div[style*="aspect-ratio"], article, div[role="dialog"]') || img.parentElement;
      if (!container || container.querySelector('.social-dl-btn-container') || container.querySelector('video')) return;

      const btn = createButton('快取下載此照片', () => {
        const id = Date.now().toString().slice(-4);
        exportSpecificImage(img, `Instagram_照片_${id}.jpg`);
      });

      if (getComputedStyle(container).position === 'static') {
        container.style.position = 'relative';
      }
      container.appendChild(btn);
    });
  }

  // -------------------------------------------------------------------------
  // 5. Facebook 掃描與掛載 (精準定位動態牆貼文、Reels、獨立影片框)
  // -------------------------------------------------------------------------
  function scanFacebook() {
    if (!location.hostname.includes('facebook.com')) return;

    // A. 影片掃描
    const videos = document.querySelectorAll('video');
    videos.forEach(video => {
      // 鎖定該影片所屬之貼文或 Reels 容器
      const container = video.closest('div[role="article"], div[data-pagelet*="FeedUnit"], div[data-pagelet*="Video"], div[role="main"], div[data-visualcompletion]') || video.parentElement;
      if (!container || container.querySelector('.social-dl-btn-container')) return;

      const isReel = location.pathname.includes('/reel/') || location.pathname.includes('/reels/');
      const label = isReel ? '快取下載此 Reel' : '快取下載此 FB 影片';

      const btn = createButton(label, () => {
        const id = Date.now().toString().slice(-4);
        exportSpecificVideo(video, container, `Facebook_${isReel ? 'Reel' : '影片'}_${id}.mp4`, 'Facebook');
      });

      if (getComputedStyle(container).position === 'static') {
        container.style.position = 'relative';
      }
      container.appendChild(btn);
    });

    // B. 貼文照片掃描
    const images = document.querySelectorAll('div[role="article"] img, div[data-pagelet*="FeedUnit"] img');
    images.forEach(img => {
      // 排除個人大頭貼 (大頭貼通常是圓形或小於 160px)
      if (img.width < 180 || img.height < 180) return;
      const container = img.closest('div[role="article"], div[data-pagelet*="FeedUnit"]') || img.parentElement;
      if (!container || container.querySelector('.social-dl-btn-container') || container.querySelector('video')) return;

      const btn = createButton('快取下載此 FB 照片', () => {
        const id = Date.now().toString().slice(-4);
        exportSpecificImage(img, `Facebook_照片_${id}.jpg`);
      });

      if (getComputedStyle(container).position === 'static') {
        container.style.position = 'relative';
      }
      container.appendChild(btn);
    });
  }

  // -------------------------------------------------------------------------
  // 6. 整合監聽 (僅啟用 Facebook 與 Instagram，停用 TikTok/抖音)
  // -------------------------------------------------------------------------
  function scanAll() {
    scanInstagram();
    scanFacebook();
  }

  scanAll();
  const observer = new MutationObserver(() => {
    scanAll();
  });
  observer.observe(document.body, { childList: true, subtree: true });
})();
