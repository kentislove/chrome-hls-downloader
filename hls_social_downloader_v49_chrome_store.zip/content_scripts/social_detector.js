/**
 * 社群網頁快取優先提取架構 (Content Script - v49 Cache-First Architecture)
 * 支援平台：Facebook、Instagram、TikTok、抖音 (Douyin)
 * 核心哲學：反求諸己！不呼叫外部遠端爬蟲，直接從當前 Chrome 瀏覽器之記憶體、Canvas 與 HTTP 快取榨取檔案
 */

(() => {
  // 建立提示 Toast
  let toastEl = null;
  function showToast(text, duration = 3000) {
    if (!toastEl) {
      toastEl = document.createElement('div');
      toastEl.className = 'social-dl-toast';
      document.body.appendChild(toastEl);
    }
    toastEl.innerHTML = `<span>⚡</span> <span>${text}</span>`;
    toastEl.classList.add('show');
    clearTimeout(toastEl._timer);
    toastEl._timer = setTimeout(() => {
      toastEl.classList.remove('show');
    }, duration);
  }

  // 下載圖示 SVG
  const downloadIcon = `
    <svg viewBox="0 0 24 24">
      <path d="M19.35 10.04C18.67 6.59 15.64 4 12 4 9.11 4 6.6 5.64 5.35 8.04 2.34 8.36 0 10.91 0 14c0 3.31 2.69 6 6 6h13c2.76 0 5-2.24 5-5 0-2.64-2.05-4.78-4.65-4.96zM17 13l-5 5-5-5h3V9h4v4h3z"/>
    </svg>
  `;

  // 建立浮動下載按鈕
  function createButton(label, onClick) {
    const container = document.createElement('div');
    container.className = 'social-dl-btn-container';
    
    const btn = document.createElement('button');
    btn.type = 'button';
    btn.className = 'social-dl-btn';
    btn.innerHTML = `${downloadIcon} <span>${label}</span>`;
    btn.addEventListener('click', (e) => {
      e.preventDefault();
      e.stopPropagation();
      onClick();
    });
    
    container.appendChild(btn);
    return container;
  }

  // 觸發本機檔案儲存 (優先呼叫擴充套件 Downloads API，備用 a[download])
  function triggerSave(url, filename) {
    chrome.runtime.sendMessage({
      method: 'download-cached-file',
      url: url,
      filename: filename,
      saveAs: false
    }, res => {
      if (!res || res.error) {
        // 備用瀏覽器 DOM 下載
        const a = document.createElement('a');
        a.href = url;
        a.download = filename;
        document.body.appendChild(a);
        a.click();
        setTimeout(() => a.remove(), 1000);
      }
    });
  }

  // 1. 照片記憶體快取直接導出 (Canvas 畫布導出 + force-cache)
  async function exportCachedImage(img, filename) {
    showToast('⏳ 正在從瀏覽器記憶體導出高畫質照片...', 2000);

    // 途徑 A：Canvas 畫布直接從記憶體複製像素
    try {
      const canvas = document.createElement('canvas');
      canvas.width = img.naturalWidth || img.width;
      canvas.height = img.naturalHeight || img.height;
      const ctx = canvas.getContext('2d');
      ctx.drawImage(img, 0, 0);

      canvas.toBlob(blob => {
        if (blob) {
          const blobUrl = URL.createObjectURL(blob);
          triggerSave(blobUrl, filename);
          showToast('✅ 成功從記憶體導出照片並儲存！', 2500);
        } else {
          fallbackImageCache(img, filename);
        }
      }, 'image/jpeg', 0.98);
      return;
    } catch (e) {
      // 若受同源政策限制，走途徑 B
    }

    fallbackImageCache(img, filename);
  }

  // 途徑 B：強制本機快取請求 (force-cache)
  function fallbackImageCache(img, filename) {
    let src = img.currentSrc || img.src;
    if (img.srcset) {
      const parts = img.srcset.split(',').map(s => s.trim().split(' '));
      if (parts.length > 0) {
        src = parts[parts.length - 1][0] || src;
      }
    }

    fetch(src, { cache: 'force-cache' })
      .then(r => r.blob())
      .then(blob => {
        const blobUrl = URL.createObjectURL(blob);
        triggerSave(blobUrl, filename);
        showToast('✅ 成功從 Chrome 快取儲存照片！', 2500);
      })
      .catch(() => {
        // 直接交給擴充套件下載
        triggerSave(src, filename);
        showToast('✅ 已傳送至 Chrome 下載佇列！', 2500);
      });
  }

  // 2. 影片快取直接導出
  function exportCachedVideo(video, filename, platform) {
    const candidates = [
      video.currentSrc,
      video.src,
      video.querySelector('source')?.src,
      video.getAttribute('src')
    ];
    let directUrl = null;
    for (const s of candidates) {
      if (s && s.startsWith('http') && !s.startsWith('blob:')) {
        directUrl = s;
        break;
      }
    }

    if (directUrl) {
      showToast(`⏳ 正在從 Chrome 本機快取提取 ${platform} 影片...`, 2000);
      // 強制使用 Chrome 本機快取讀取
      fetch(directUrl, { cache: 'force-cache' })
        .then(r => r.blob())
        .then(blob => {
          const blobUrl = URL.createObjectURL(blob);
          triggerSave(blobUrl, filename);
          showToast(`✅ 已直接從 Chrome 快取導出完整影片！`, 3000);
        })
        .catch(() => {
          // 若有 CORS 限制，交由擴充套件主下載器透過後台帶 Referer 下載
          chrome.runtime.sendMessage({
            method: 'open-downloader-for-media',
            item: {
              url: directUrl,
              title: filename.replace('.mp4', ''),
              ext: 'mp4'
            }
          });
          showToast('✅ 已將快取影片載入下載器！', 2500);
        });
    } else {
      // MSE / Blob 加密分段串流 (Facebook / Instagram 部分影片)
      showToast(`🔍 正在從瀏覽器分頁緩衝區抓取已播放串流...`, 2500);
      chrome.runtime.sendMessage({ method: 'open-downloader-current-tab' });
    }
  }

  // -------------------------------------------------------------
  // 3. Instagram 掃描器
  // -------------------------------------------------------------
  function scanInstagram() {
    if (!location.hostname.includes('instagram.com')) return;

    // 影片掃描
    const videos = document.querySelectorAll('video');
    videos.forEach(video => {
      const container = video.closest('div[style*="aspect-ratio"], div._ab6-, div._aa61, article, div[role="dialog"], section, main') || video.parentElement;
      if (!container || container.querySelector('.social-dl-btn-container')) return;

      const isStory = location.pathname.includes('/stories/');
      const label = isStory ? '快取下載此限動' : '快取下載 IG 影片';

      const btn = createButton(label, () => {
        exportCachedVideo(video, `Instagram_影片_${Date.now()}.mp4`, 'Instagram');
      });

      if (getComputedStyle(container).position === 'static') {
        container.style.position = 'relative';
      }
      container.appendChild(btn);
    });

    // 照片掃描
    const images = document.querySelectorAll('article img[srcset], div[role="dialog"] img[srcset], section img[srcset]');
    images.forEach(img => {
      if (img.width < 180 || img.height < 180) return;
      const container = img.closest('div._aagv, div[style*="aspect-ratio"], article, div[role="dialog"]') || img.parentElement;
      if (!container || container.querySelector('.social-dl-btn-container') || container.querySelector('video')) return;

      const btn = createButton('快取下載 IG 照片', () => {
        exportCachedImage(img, `Instagram_照片_${Date.now()}.jpg`);
      });

      if (getComputedStyle(container).position === 'static') {
        container.style.position = 'relative';
      }
      container.appendChild(btn);
    });
  }

  // -------------------------------------------------------------
  // 4. Facebook 掃描器
  // -------------------------------------------------------------
  function scanFacebook() {
    if (!location.hostname.includes('facebook.com')) return;

    const videos = document.querySelectorAll('video');
    videos.forEach(video => {
      const container = video.closest('div[data-pagelet*="Video"], div[data-pagelet*="FeedUnit"], div[role="article"], div[data-visualcompletion], div[role="main"]') || video.parentElement;
      if (!container || container.querySelector('.social-dl-btn-container')) return;

      const btn = createButton('快取下載 FB 影片', () => {
        exportCachedVideo(video, `Facebook_影片_${Date.now()}.mp4`, 'Facebook');
      });

      if (getComputedStyle(container).position === 'static') {
        container.style.position = 'relative';
      }
      container.appendChild(btn);
    });
  }

  // -------------------------------------------------------------
  // 5. TikTok 與 抖音 (Douyin) 掃描器
  // -------------------------------------------------------------
  function scanTikTokAndDouyin() {
    const isTikTok = location.hostname.includes('tiktok.com');
    const isDouyin = location.hostname.includes('douyin.com');
    if (!isTikTok && !isDouyin) return;

    const videos = document.querySelectorAll('video');
    videos.forEach(video => {
      const container = video.closest('div[data-e2e="feed-video"], div[class*="DivVideoWrapper"], div[class*="xgplayer"], div[data-e2e="user-post-item"]') || video.parentElement;
      if (!container || container.querySelector('.social-dl-btn-container')) return;

      const platform = isDouyin ? '抖音' : 'TikTok';
      const btn = createButton(`快取下載 ${platform} 影音`, () => {
        exportCachedVideo(video, `${platform}_影音_${Date.now()}.mp4`, platform);
      });

      if (getComputedStyle(container).position === 'static') {
        container.style.position = 'relative';
      }
      container.appendChild(btn);
    });
  }

  // -------------------------------------------------------------
  // 6. 動態監聽
  // -------------------------------------------------------------
  function scanAll() {
    scanInstagram();
    scanFacebook();
    scanTikTokAndDouyin();
  }

  scanAll();
  const observer = new MutationObserver(() => {
    scanAll();
  });
  observer.observe(document.body, { childList: true, subtree: true });
})();
