/**
 * 社群網頁 Section 容器定向與 Progressive 直出下載引擎 (v54 Section API Progressive Downloader)
 * 核心哲學：
 * 1. 嚴格基於 DOM Section / Article 容器進行貼文身分隔離，徹底消滅「抓 A 出現 B、D、E、F、G」亂套問題。
 * 2. 優先索取官方伺服器端音畫合一的 Progressive MP4 直連，徹底解決「缺聲音或缺畫面」問題。
 * 3. 極致輕量化設計：不載入 WebAssembly 轉檔器，不常駐背景吃記憶體，開上百個視窗依然流暢如飛！
 */

(() => {
  // 建立提示訊息 (Toast)
  let toastEl = null;
  function showToast(text, duration = 3000) {
    if (!toastEl) {
      toastEl = document.createElement('div');
      toastEl.className = 'social-dl-toast';
      document.body.appendChild(toastEl);
    }
    toastEl.innerHTML = `<span>⚡</span> <span>${text}</span>`;
    toastEl.classList.add('show');
    clearTimeout(toastEl._timer);
    toastEl._timer = setTimeout(() => {
      toastEl.classList.remove('show');
    }, duration);
  }

  // 下載圖示 SVG
  const downloadIcon = `
    <svg viewBox="0 0 24 24">
      <path d="M19.35 10.04C18.67 6.59 15.64 4 12 4 9.11 4 6.6 5.64 5.35 8.04 2.34 8.36 0 10.91 0 14c0 3.31 2.69 6 6 6h13c2.76 0 5-2.24 5-5 0-2.64-2.05-4.78-4.65-4.96zM17 13l-5 5-5-5h3V9h4v4h3z"/>
    </svg>
  `;

  // 建立浮動下載按鈕
  function createButton(label, onClick, customClass = '') {
    const container = document.createElement('div');
    container.className = `social-dl-btn-container ${customClass}`;
    
    const btn = document.createElement('button');
    btn.type = 'button';
    btn.className = `social-dl-btn ${customClass ? customClass + '-btn' : ''}`;
    btn.innerHTML = `${downloadIcon} <span>${label}</span>`;
    btn.addEventListener('click', (e) => {
      e.preventDefault();
      e.stopPropagation();
      onClick();
    });
    
    container.appendChild(btn);
    return container;
  }

  // 清理影片網址中的分段 Range 限制參數 (bytestart/byteend)，確保下載完整檔案
  function cleanVideoUrl(rawUrl) {
    if (!rawUrl) return '';
    try {
      const u = new URL(rawUrl);
      u.searchParams.delete('bytestart');
      u.searchParams.delete('byteend');
      return u.href;
    } catch (e) {
      return rawUrl.replace(/([?&])bytestart=\d+(&?)/, '$1').replace(/([?&])byteend=\d+(&?)/, '$1');
    }
  }

  // 觸發本機檔案儲存 (優先呼叫擴充套件 Downloads API)
  function triggerSave(url, filename) {
    chrome.runtime.sendMessage({
      method: 'download-cached-file',
      url: url,
      filename: filename,
      saveAs: false
    }, res => {
      if (!res || res.error) {
        const a = document.createElement('a');
        a.href = url;
        a.download = filename;
        document.body.appendChild(a);
        a.click();
        setTimeout(() => a.remove(), 1000);
      }
    });
  }

  // -------------------------------------------------------------------------
  // 1. DOM Section 貼文專屬身分識別碼 (Post ID / Shortcode) 提取
  // -------------------------------------------------------------------------
  function getSectionPermalink(section) {
    if (!section) return null;

    // Instagram: /p/ 或 /reel/
    const igLink = section.querySelector('a[href*="/p/"], a[href*="/reel/"]');
    if (igLink && igLink.href) return igLink.href;

    // Facebook: /reel/, /watch/, /videos/, /posts/, permalink
    const fbLink = section.querySelector(
      'a[href*="/reel/"], a[href*="/watch/"], a[href*="/videos/"], a[href*="/posts/"], a[href*="permalink.php"], a[href*="story.php"]'
    );
    if (fbLink && fbLink.href) return fbLink.href;

    return null;
  }

  // -------------------------------------------------------------------------
  // 2. React 內部記憶體深度挖掘 (優先尋找官方 Progressive 音畫合一 MP4)
  // -------------------------------------------------------------------------
  function extractProgressiveFromReact(element) {
    if (!element) return null;

    const visited = new Set();
    const targetKeys = [
      'playable_url_quality_hd',
      'browser_native_hd_url',
      'playable_url',
      'browser_native_sd_url',
      'hd_src',
      'sd_src',
      'video_url'
    ];

    function searchInObj(obj, depth) {
      if (!obj || depth > 7 || visited.has(obj)) return null;
      if (typeof obj !== 'object' && typeof obj !== 'function') return null;
      visited.add(obj);

      for (const k of targetKeys) {
        if (typeof obj[k] === 'string' && obj[k].startsWith('http')) {
          return cleanVideoUrl(obj[k]);
        }
      }

      if (Array.isArray(obj.video_versions) && obj.video_versions.length > 0) {
        const first = obj.video_versions[0];
        if (first && typeof first.url === 'string') {
          return cleanVideoUrl(first.url);
        }
      }

      for (const key of Object.keys(obj)) {
        try {
          const val = obj[key];
          if (typeof val === 'string' && val.startsWith('http') && val.includes('.mp4')) {
            if (!val.includes('audio') && (val.includes('fbcdn.net') || val.includes('cdninstagram.com'))) {
              return cleanVideoUrl(val);
            }
          } else if (typeof val === 'object' && val !== null) {
            const res = searchInObj(val, depth + 1);
            if (res) return res;
          }
        } catch (e) {}
      }
      return null;
    }

    let curr = element;
    let level = 0;
    while (curr && level < 7) {
      for (const prop in curr) {
        if (prop.startsWith('__reactFiber') || prop.startsWith('__reactProps') || prop.startsWith('__reactInternalInstance')) {
          const url = searchInObj(curr[prop], 0);
          if (url) return url;
        }
      }
      curr = curr.parentElement;
      level++;
    }

    return null;
  }

  // -------------------------------------------------------------------------
  // 3. Section 核心影片下載調度 (三級防護，絕不抓錯貼文)
  // -------------------------------------------------------------------------
  async function downloadSectionVideo(video, section, filename, platform) {
    showToast(`🔍 正在定向鎖定此 ${platform} 影片 (音畫合一檢測)...`, 2000);

    // 階段 1：直接檢查原生 video.currentSrc
    const directSrc = video.currentSrc || video.src || video.querySelector('source')?.src;
    if (directSrc && directSrc.startsWith('http') && !directSrc.startsWith('blob:')) {
      const fullUrl = cleanVideoUrl(directSrc);
      triggerSave(fullUrl, filename);
      showToast(`✅ 已從原生快取下載此 ${platform} 完整影片！`, 3000);
      return;
    }

    // 階段 2：從該 Section 內部的 React Fiber 樹直接挖掘 Progressive MP4
    const reactUrl = extractProgressiveFromReact(video);
    if (reactUrl) {
      triggerSave(reactUrl, filename);
      showToast(`🎉 成功獲取官方 Progressive 音畫合一高畫質影片！`, 3500);
      return;
    }

    // 階段 3：使用 Section 貼文專屬網址發起【單篇貼文定向解析】(對號入座)
    const postUrl = getSectionPermalink(section) || location.href;
    if (postUrl && postUrl !== 'https://www.facebook.com/' && postUrl !== 'https://www.instagram.com/') {
      showToast(`⚡ 正在針對此專屬貼文進行定向解析 (杜絕其他貼文干擾)...`, 2500);
      chrome.runtime.sendMessage({
        method: 'download-specific-post',
        postUrl: postUrl,
        platform: platform,
        filename: filename
      }, res => {
        if (res && res.success) {
          showToast(`🎉 成功定向下載此貼文之完整音畫影片！`, 3500);
        } else {
          // 若定向解析受限，最後走分頁活動備用捕獲
          fallbackActiveCapture(postUrl, filename, platform);
        }
      });
      return;
    }

    fallbackActiveCapture(postUrl, filename, platform);
  }

  // 備用快取捕獲
  function fallbackActiveCapture(postUrl, filename, platform) {
    chrome.runtime.sendMessage({
      method: 'download-active-media',
      platform: platform,
      postUrl: postUrl,
      filename: filename
    }, res => {
      if (res && res.success) {
        showToast(`🎉 成功捕獲此目標影片！已啟動下載！`, 3500);
      } else {
        showToast(`💡 請讓此影片播放 1~2 秒以利快取完整捕獲！`, 4000);
      }
    });
  }

  // -------------------------------------------------------------------------
  // 4. Section 照片精準導出 (嚴格在容器內定位當前中心照片)
  // -------------------------------------------------------------------------
  function downloadSectionImage(section, filename) {
    showToast('⏳ 正在精準導出此張照片...', 2000);

    const imgs = Array.from(section.querySelectorAll('img')).filter(img => img.width >= 180 && img.height >= 180);
    if (imgs.length === 0) {
      showToast('⚠️ 未能在該貼文區域找到照片');
      return;
    }

    // 動態計算最靠近視窗中心的那一張
    const viewportCenterY = window.innerHeight / 2;
    const viewportCenterX = window.innerWidth / 2;
    let targetImg = imgs[0];
    let minDist = Infinity;

    for (const img of imgs) {
      const rect = img.getBoundingClientRect();
      if (rect.width > 0 && rect.height > 0 && rect.bottom > 0 && rect.top < window.innerHeight) {
        const cy = rect.top + rect.height / 2;
        const cx = rect.left + rect.width / 2;
        const dist = Math.hypot(cx - viewportCenterX, cy - viewportCenterY);
        if (dist < minDist) {
          minDist = dist;
          targetImg = img;
        }
      }
    }

    // Canvas 直出或快取 fetch
    try {
      const canvas = document.createElement('canvas');
      canvas.width = targetImg.naturalWidth || targetImg.width;
      canvas.height = targetImg.naturalHeight || targetImg.height;
      const ctx = canvas.getContext('2d');
      ctx.drawImage(targetImg, 0, 0);

      canvas.toBlob(blob => {
        if (blob) {
          const blobUrl = URL.createObjectURL(blob);
          triggerSave(blobUrl, filename);
          showToast('✅ 成功從記憶體無損導出該張照片！', 2500);
        } else {
          fallbackImageDownload(targetImg, filename);
        }
      }, 'image/jpeg', 0.98);
      return;
    } catch (e) {}

    fallbackImageDownload(targetImg, filename);
  }

  function fallbackImageDownload(img, filename) {
    let src = img.currentSrc || img.src;
    if (img.srcset) {
      const parts = img.srcset.split(',').map(s => s.trim().split(' '));
      if (parts.length > 0) src = parts[parts.length - 1][0] || src;
    }
    fetch(src, { cache: 'force-cache' })
      .then(r => r.blob())
      .then(blob => {
        const blobUrl = URL.createObjectURL(blob);
        triggerSave(blobUrl, filename);
        showToast('✅ 成功下載該張照片！', 2500);
      })
      .catch(() => {
        triggerSave(src, filename);
        showToast('✅ 已加入照片下載佇列！', 2500);
      });
  }

  // -------------------------------------------------------------------------
  // 5. Instagram Section 掃描與掛載
  // -------------------------------------------------------------------------
  function scanInstagramFeed() {
    if (!location.hostname.includes('instagram.com') || location.pathname.includes('/stories/')) return;

    // 尋找每一個獨立貼文容器 (<article>)
    const sections = document.querySelectorAll('article, div[role="dialog"]');
    sections.forEach(section => {
      if (section.querySelector('.social-dl-btn-container')) return;

      const hasVideo = section.querySelector('video');
      const hasImage = section.querySelector('img');

      if (!hasVideo && !hasImage) return;

      const container = document.createElement('div');
      container.className = 'social-dl-btn-container';

      if (hasVideo) {
        const btnVideo = document.createElement('button');
        btnVideo.type = 'button';
        btnVideo.className = 'social-dl-btn';
        btnVideo.innerHTML = `${downloadIcon} <span>下載此 IG 影片 (音畫合一)</span>`;
        btnVideo.addEventListener('click', (e) => {
          e.preventDefault();
          e.stopPropagation();
          const targetVideo = section.querySelector('video');
          if (targetVideo) {
            const id = Date.now().toString().slice(-4);
            downloadSectionVideo(targetVideo, section, `Instagram_影片_${id}.mp4`, 'Instagram');
          }
        });
        container.appendChild(btnVideo);
      }

      if (hasImage) {
        const btnImg = document.createElement('button');
        btnImg.type = 'button';
        btnImg.className = 'social-dl-btn';
        btnImg.innerHTML = `${downloadIcon} <span>下載此張照片</span>`;
        btnImg.addEventListener('click', (e) => {
          e.preventDefault();
          e.stopPropagation();
          const id = Date.now().toString().slice(-4);
          downloadSectionImage(section, `Instagram_照片_${id}.jpg`);
        });
        container.appendChild(btnImg);
      }

      if (getComputedStyle(section).position === 'static') {
        section.style.position = 'relative';
      }
      section.appendChild(container);
    });
  }

  // -------------------------------------------------------------------------
  // 6. Instagram 限時動態 (Stories) 專屬處理器
  // -------------------------------------------------------------------------
  function scanInstagramStories() {
    if (!location.hostname.includes('instagram.com') || !location.pathname.includes('/stories/')) {
      const p = document.querySelector('.social-dl-story-panel');
      if (p) p.remove();
      return;
    }

    if (document.querySelector('.social-dl-story-panel')) return;

    const panel = document.createElement('div');
    panel.className = 'social-dl-story-panel';

    const btn = document.createElement('button');
    btn.type = 'button';
    btn.className = 'social-dl-btn social-dl-story-btn';
    btn.innerHTML = `${downloadIcon} <span>📥 下載當前限動 (音畫合一)</span>`;
    btn.addEventListener('click', (e) => {
      e.preventDefault();
      e.stopPropagation();

      const storyVideo = document.querySelector('section video, div[role="dialog"] video, main video');
      if (storyVideo && storyVideo.src) {
        downloadSectionVideo(storyVideo, document.body, `Instagram_限動影片_${Date.now()}.mp4`, 'Instagram');
        return;
      }

      const storyImages = Array.from(document.querySelectorAll('section img, div[role="dialog"] img, main img')).filter(img => img.width > 250 || img.height > 250);
      if (storyImages.length > 0) {
        downloadSectionImage(document.body, `Instagram_限動照片_${Date.now()}.jpg`);
      } else {
        showToast('💡 正在即時捕捉限動串流，請讓畫面播放 1 秒後重試！');
      }
    });

    panel.appendChild(btn);
    document.body.appendChild(panel);
  }

  // -------------------------------------------------------------------------
  // 7. Facebook Section 掃描與掛載
  // -------------------------------------------------------------------------
  function scanFacebook() {
    if (!location.hostname.includes('facebook.com')) return;

    // 尋找每一個獨立貼文或 Reels 容器
    const sections = document.querySelectorAll('div[role="article"], div[data-pagelet*="FeedUnit"], div[data-pagelet*="Video"]');
    sections.forEach(section => {
      if (section.querySelector('.social-dl-btn-container')) return;

      const hasVideo = section.querySelector('video');
      const hasImage = section.querySelector('img');

      if (!hasVideo && !hasImage) return;

      const container = document.createElement('div');
      container.className = 'social-dl-btn-container';

      if (hasVideo) {
        const isReel = location.pathname.includes('/reel/') || location.pathname.includes('/reels/');
        const btnVideo = document.createElement('button');
        btnVideo.type = 'button';
        btnVideo.className = 'social-dl-btn';
        btnVideo.innerHTML = `${downloadIcon} <span>下載此 ${isReel ? 'Reel' : 'FB 影片'} (音畫合一)</span>`;
        btnVideo.addEventListener('click', (e) => {
          e.preventDefault();
          e.stopPropagation();
          const targetVideo = section.querySelector('video');
          if (targetVideo) {
            const id = Date.now().toString().slice(-4);
            downloadSectionVideo(targetVideo, section, `Facebook_${isReel ? 'Reel' : '影片'}_${id}.mp4`, 'Facebook');
          }
        });
        container.appendChild(btnVideo);
      }

      if (hasImage && !hasVideo) {
        const btnImg = document.createElement('button');
        btnImg.type = 'button';
        btnImg.className = 'social-dl-btn';
        btnImg.innerHTML = `${downloadIcon} <span>下載此 FB 照片</span>`;
        btnImg.addEventListener('click', (e) => {
          e.preventDefault();
          e.stopPropagation();
          const id = Date.now().toString().slice(-4);
          downloadSectionImage(section, `Facebook_照片_${id}.jpg`);
        });
        container.appendChild(btnImg);
      }

      if (getComputedStyle(section).position === 'static') {
        section.style.position = 'relative';
      }
      section.appendChild(container);
    });
  }

  // -------------------------------------------------------------------------
  // 8. 整合啟動
  // -------------------------------------------------------------------------
  function scanAll() {
    scanInstagramFeed();
    scanInstagramStories();
    scanFacebook();
  }

  scanAll();
  const observer = new MutationObserver(() => {
    scanAll();
  });
  observer.observe(document.body, { childList: true, subtree: true });
})();
