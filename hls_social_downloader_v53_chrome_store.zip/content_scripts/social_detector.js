/**
 * 社群網頁快取優先與 DOM 精準目標鎖定架構 (Content Script - v53 Precision & AV Merge)
 * 專注平台：Facebook、Instagram
 * 核心升級：
 * 1. Facebook：深度挖掘 Progressive MP4 (音畫合一)，避免 DASH 串流缺聲音或缺畫面的問題。
 * 2. Instagram 貼文：採用視窗中心動態選取 (Active Viewport Selector)，精準鎖定當前貼文正在顯示的照片，徹底杜絕抓到下一篇或預載照片。
 * 3. Instagram 限時動態 (Stories)：專屬全螢幕頂層懸浮控制面板，完整捕獲限動高畫質影片與無 srcset 限動原圖。
 */

(() => {
  // 建立提示訊息 (Toast)
  let toastEl = null;
  function showToast(text, duration = 3000) {
    if (!toastEl) {
      toastEl = document.createElement('div');
      toastEl.className = 'social-dl-toast';
      document.body.appendChild(toastEl);
    }
    toastEl.innerHTML = `<span>⚡</span> <span>${text}</span>`;
    toastEl.classList.add('show');
    clearTimeout(toastEl._timer);
    toastEl._timer = setTimeout(() => {
      toastEl.classList.remove('show');
    }, duration);
  }

  // 下載圖示 SVG
  const downloadIcon = `
    <svg viewBox="0 0 24 24">
      <path d="M19.35 10.04C18.67 6.59 15.64 4 12 4 9.11 4 6.6 5.64 5.35 8.04 2.34 8.36 0 10.91 0 14c0 3.31 2.69 6 6 6h13c2.76 0 5-2.24 5-5 0-2.64-2.05-4.78-4.65-4.96zM17 13l-5 5-5-5h3V9h4v4h3z"/>
    </svg>
  `;

  // 建立浮動下載按鈕
  function createButton(label, onClick, customClass = '') {
    const container = document.createElement('div');
    container.className = `social-dl-btn-container ${customClass}`;
    
    const btn = document.createElement('button');
    btn.type = 'button';
    btn.className = `social-dl-btn ${customClass ? customClass + '-btn' : ''}`;
    btn.innerHTML = `${downloadIcon} <span>${label}</span>`;
    btn.addEventListener('click', (e) => {
      e.preventDefault();
      e.stopPropagation();
      onClick();
    });
    
    container.appendChild(btn);
    return container;
  }

  // 清理影片網址中的分段 Range 限制參數 (bytestart/byteend)，確保下載為 100% 完整檔案
  function cleanVideoUrl(rawUrl) {
    if (!rawUrl) return '';
    try {
      const u = new URL(rawUrl);
      u.searchParams.delete('bytestart');
      u.searchParams.delete('byteend');
      return u.href;
    } catch (e) {
      return rawUrl.replace(/([?&])bytestart=\d+(&?)/, '$1').replace(/([?&])byteend=\d+(&?)/, '$1');
    }
  }

  // 觸發本機檔案儲存 (優先呼叫擴充套件 Downloads API，備用 a[download])
  function triggerSave(url, filename) {
    chrome.runtime.sendMessage({
      method: 'download-cached-file',
      url: url,
      filename: filename,
      saveAs: false
    }, res => {
      if (!res || res.error) {
        const a = document.createElement('a');
        a.href = url;
        a.download = filename;
        document.body.appendChild(a);
        a.click();
        setTimeout(() => a.remove(), 1000);
      }
    });
  }

  // -------------------------------------------------------------------------
  // 1. React 內部屬性深度挖掘 (優先尋找音視訊合一的 Progressive MP4 串流)
  // -------------------------------------------------------------------------
  function extractMediaUrlFromReact(element) {
    if (!element) return null;

    const visited = new Set();
    // 優先順序：必須是音畫合一的完整串流 (Progressive MP4)
    const targetKeys = [
      'playable_url_quality_hd',
      'playable_url',
      'browser_native_hd_url',
      'browser_native_sd_url',
      'hd_src',
      'sd_src',
      'video_url'
    ];

    function searchInObj(obj, depth) {
      if (!obj || depth > 7 || visited.has(obj)) return null;
      if (typeof obj !== 'object' && typeof obj !== 'function') return null;
      visited.add(obj);

      // 檢查是否含有 Progressive MP4 直連屬性
      for (const k of targetKeys) {
        if (typeof obj[k] === 'string' && obj[k].startsWith('http')) {
          return cleanVideoUrl(obj[k]);
        }
      }

      // 檢查 Instagram video_versions 陣列
      if (Array.isArray(obj.video_versions) && obj.video_versions.length > 0) {
        const first = obj.video_versions[0];
        if (first && typeof first.url === 'string') {
          return cleanVideoUrl(first.url);
        }
      }

      // 遞迴搜尋
      for (const key of Object.keys(obj)) {
        try {
          const val = obj[key];
          if (typeof val === 'string' && val.startsWith('http') && val.includes('.mp4')) {
            // 排除純音軌或切片
            if (!val.includes('audio') && (val.includes('fbcdn.net') || val.includes('cdninstagram.com'))) {
              return cleanVideoUrl(val);
            }
          } else if (typeof val === 'object' && val !== null) {
            const res = searchInObj(val, depth + 1);
            if (res) return res;
          }
        } catch (e) {}
      }
      return null;
    }

    let curr = element;
    let level = 0;
    while (curr && level < 7) {
      for (const prop in curr) {
        if (prop.startsWith('__reactFiber') || prop.startsWith('__reactProps') || prop.startsWith('__reactInternalInstance')) {
          const url = searchInObj(curr[prop], 0);
          if (url) return url;
        }
      }
      curr = curr.parentElement;
      level++;
    }

    return null;
  }

  // 取得目標貼文的永久專屬連結 (Permalink)
  function getPostPermalink(container) {
    if (!container) return null;
    const linkEl = container.querySelector(
      'a[href*="/reel/"], a[href*="/p/"], a[href*="/videos/"], a[href*="/watch/"], a[href*="/posts/"], a[href*="permalink.php"]'
    );
    return linkEl?.href || null;
  }

  // -------------------------------------------------------------------------
  // 2. 照片無損與快取導出
  // -------------------------------------------------------------------------
  async function exportSpecificImage(img, filename) {
    showToast('⏳ 正在從快取精準導出該張照片...', 2000);

    // 途徑 A：Canvas 畫布直出 (記憶體無損複製)
    try {
      const canvas = document.createElement('canvas');
      canvas.width = img.naturalWidth || img.width;
      canvas.height = img.naturalHeight || img.height;
      const ctx = canvas.getContext('2d');
      ctx.drawImage(img, 0, 0);

      canvas.toBlob(blob => {
        if (blob) {
          const blobUrl = URL.createObjectURL(blob);
          triggerSave(blobUrl, filename);
          showToast('✅ 成功導出該張照片！已儲存至您的電腦！', 2500);
        } else {
          fallbackFetchImage(img, filename);
        }
      }, 'image/jpeg', 0.98);
      return;
    } catch (e) {}

    fallbackFetchImage(img, filename);
  }

  function fallbackFetchImage(img, filename) {
    let src = img.currentSrc || img.src;
    if (img.srcset) {
      const parts = img.srcset.split(',').map(s => s.trim().split(' '));
      if (parts.length > 0) {
        src = parts[parts.length - 1][0] || src;
      }
    }

    fetch(src, { cache: 'force-cache' })
      .then(r => r.blob())
      .then(blob => {
        const blobUrl = URL.createObjectURL(blob);
        triggerSave(blobUrl, filename);
        showToast('✅ 成功從快取下載該張照片！', 2500);
      })
      .catch(() => {
        triggerSave(src, filename);
        showToast('✅ 已啟動照片下載佇列！', 2500);
      });
  }

  // -------------------------------------------------------------------------
  // 3. 影片精準下載 (含音畫合一檢測)
  // -------------------------------------------------------------------------
  async function exportSpecificVideo(video, container, filename, platform) {
    showToast(`🔍 正在精準鎖定此 ${platform} 影片 (音畫完整合一檢測)...`, 2000);

    // 步驟 1：檢查原生 src
    const directSrc = video.currentSrc || video.src || video.querySelector('source')?.src;
    if (directSrc && directSrc.startsWith('http') && !directSrc.startsWith('blob:')) {
      const fullUrl = cleanVideoUrl(directSrc);
      triggerSave(fullUrl, filename);
      showToast(`✅ 已從原生快取啟動此 ${platform} 完整影片下載！`, 3000);
      return;
    }

    // 步驟 2：從 React 核心挖掘 Progressive MP4 (自帶聲音與畫面)
    const reactUrl = extractMediaUrlFromReact(video);
    if (reactUrl) {
      triggerSave(reactUrl, filename);
      showToast(`🎉 成功鎖定 Progressive 高畫質完整影片 (音畫合一)！`, 3500);
      return;
    }

    // 步驟 3：背景分流/雙軌捕獲 (處理 Facebook DASH 分離音軌與視訊軌)
    const postUrl = getPostPermalink(container) || location.href;
    showToast(`⚡ 正在從網路快取擷取目標影片 (視訊軌 + 音訊軌)...`, 2000);
    
    chrome.runtime.sendMessage({
      method: 'download-active-media',
      platform: platform,
      postUrl: postUrl,
      filename: filename
    }, res => {
      if (res && res.success) {
        if (res.isDualTrack) {
          showToast(`🎉 已成功同時捕獲此影片之【畫面軌】與【音效軌】！`, 4000);
        } else {
          showToast(`🎉 成功捕獲此目標完整影片！已啟動下載！`, 3500);
        }
      } else {
        const msg = res?.error || '請讓此特定影片播放 1~2 秒以利快取完整捕獲！';
        showToast(`💡 ${msg}`, 4000);
      }
    });
  }

  // -------------------------------------------------------------------------
  // 4. Instagram 專屬處理器 (解決照片順序錯亂與抓到下一篇問題)
  // -------------------------------------------------------------------------
  
  // 在貼文容器內部，精準計算目前位於視窗中心且真正可見的照片
  function getCurrentlyVisibleImage(article) {
    const imgs = Array.from(article.querySelectorAll('img')).filter(img => {
      return img.width >= 180 && img.height >= 180;
    });
    if (imgs.length === 0) return null;
    if (imgs.length === 1) return imgs[0];

    const viewportCenterY = window.innerHeight / 2;
    const viewportCenterX = window.innerWidth / 2;
    let bestImg = null;
    let minDistance = Infinity;

    for (const img of imgs) {
      const rect = img.getBoundingClientRect();
      // 必須在目前可見的視窗範圍內，且寬高大於 0
      if (rect.width > 0 && rect.height > 0 && rect.bottom > 0 && rect.top < window.innerHeight) {
        // 計算該圖片中心與視窗中心的距離
        const imgCenterY = rect.top + rect.height / 2;
        const imgCenterX = rect.left + rect.width / 2;
        const dist = Math.hypot(imgCenterX - viewportCenterX, imgCenterY - viewportCenterY);
        if (dist < minDistance) {
          minDistance = dist;
          bestImg = img;
        }
      }
    }
    return bestImg || imgs[0];
  }

  function scanInstagramFeed() {
    if (!location.hostname.includes('instagram.com') || location.pathname.includes('/stories/')) return;

    // 尋找每一個獨立貼文容器 (article)
    const articles = document.querySelectorAll('article, div[role="dialog"]');
    articles.forEach(article => {
      if (article.querySelector('.social-dl-btn-container')) return;

      const hasVideo = article.querySelector('video');
      const hasImage = article.querySelector('img[srcset]');

      if (!hasVideo && !hasImage) return;

      // 建立按鈕群組
      const container = document.createElement('div');
      container.className = 'social-dl-btn-container';

      if (hasVideo) {
        const btnVideo = document.createElement('button');
        btnVideo.type = 'button';
        btnVideo.className = 'social-dl-btn';
        btnVideo.innerHTML = `${downloadIcon} <span>快取下載 IG 影片</span>`;
        btnVideo.addEventListener('click', (e) => {
          e.preventDefault();
          e.stopPropagation();
          const targetVideo = article.querySelector('video');
          if (targetVideo) {
            const id = Date.now().toString().slice(-4);
            exportSpecificVideo(targetVideo, article, `Instagram_影片_${id}.mp4`, 'Instagram');
          }
        });
        container.appendChild(btnVideo);
      }

      if (hasImage) {
        const btnImg = document.createElement('button');
        btnImg.type = 'button';
        btnImg.className = 'social-dl-btn';
        btnImg.innerHTML = `${downloadIcon} <span>快取下載此張照片</span>`;
        btnImg.addEventListener('click', (e) => {
          e.preventDefault();
          e.stopPropagation();
          // 【核心修正】點擊當下，才精確獲取該貼文目前正在顯示的那一張照片，絕不下載到下一篇！
          const activeImg = getCurrentlyVisibleImage(article);
          if (activeImg) {
            const id = Date.now().toString().slice(-4);
            exportSpecificImage(activeImg, `Instagram_照片_${id}.jpg`);
          } else {
            showToast('⚠️ 未能在當前貼文中找到可下載的照片');
          }
        });
        container.appendChild(btnImg);
      }

      if (getComputedStyle(article).position === 'static') {
        article.style.position = 'relative';
      }
      article.appendChild(container);
    });
  }

  // -------------------------------------------------------------------------
  // 5. Instagram 限時動態 (Stories) 專屬處理器 (解決限動無法下載完全問題)
  // -------------------------------------------------------------------------
  function scanInstagramStories() {
    if (!location.hostname.includes('instagram.com') || !location.pathname.includes('/stories/')) {
      const existingPanel = document.querySelector('.social-dl-story-panel');
      if (existingPanel) existingPanel.remove();
      return;
    }

    if (document.querySelector('.social-dl-story-panel')) return;

    // 建立頂層獨立懸浮面板，確保絕不被限動操作層遮擋
    const panel = document.createElement('div');
    panel.className = 'social-dl-story-panel';

    const btn = document.createElement('button');
    btn.type = 'button';
    btn.className = 'social-dl-btn social-dl-story-btn';
    btn.innerHTML = `${downloadIcon} <span>📥 快取下載當前限動</span>`;
    btn.addEventListener('click', (e) => {
      e.preventDefault();
      e.stopPropagation();

      // 1. 優先尋找當前正在播放的全螢幕限動影片
      const storyVideo = document.querySelector('section video, div[role="dialog"] video, main video');
      if (storyVideo && storyVideo.src) {
        showToast('⏳ 正在完整擷取當前限動影片 (含音畫軌)...', 2500);
        exportSpecificVideo(storyVideo, document.body, `Instagram_限動影片_${Date.now()}.mp4`, 'Instagram');
        return;
      }

      // 2. 尋找當前限動的全螢幕焦點照片 (支援無 srcset 之大圖)
      const storyImages = Array.from(document.querySelectorAll('section img, div[role="dialog"] img, main img')).filter(img => {
        // 排除頭像小圖 (限動頭像通常小於 100px)
        return img.width > 250 || img.height > 250;
      });

      if (storyImages.length > 0) {
        // 取得最靠近畫面中央的限動主圖
        const centerImg = storyImages[0];
        exportSpecificImage(centerImg, `Instagram_限動照片_${Date.now()}.jpg`);
      } else {
        showToast('💡 正在即時捕捉當前限動串流，請讓畫面播放 1 秒後重試！');
      }
    });

    panel.appendChild(btn);
    document.body.appendChild(panel);
  }

  // -------------------------------------------------------------------------
  // 6. Facebook 處理器 (動態饋給、Reels、貼文照片)
  // -------------------------------------------------------------------------
  function scanFacebook() {
    if (!location.hostname.includes('facebook.com')) return;

    // A. 影片掃描
    const videos = document.querySelectorAll('video');
    videos.forEach(video => {
      const container = video.closest('div[role="article"], div[data-pagelet*="FeedUnit"], div[data-pagelet*="Video"], div[role="main"]') || video.parentElement;
      if (!container || container.querySelector('.social-dl-btn-container')) return;

      const isReel = location.pathname.includes('/reel/') || location.pathname.includes('/reels/');
      const label = isReel ? '快取下載此 Reel (音畫合一)' : '快取下載 FB 影片 (音畫合一)';

      const btn = createButton(label, () => {
        const id = Date.now().toString().slice(-4);
        exportSpecificVideo(video, container, `Facebook_${isReel ? 'Reel' : '影片'}_${id}.mp4`, 'Facebook');
      });

      if (getComputedStyle(container).position === 'static') {
        container.style.position = 'relative';
      }
      container.appendChild(btn);
    });

    // B. 照片掃描
    const articles = document.querySelectorAll('div[role="article"], div[data-pagelet*="FeedUnit"]');
    articles.forEach(article => {
      if (article.querySelector('.fb-photo-dl-btn')) return;
      const imgs = Array.from(article.querySelectorAll('img')).filter(img => img.width >= 200 && img.height >= 200);
      if (imgs.length === 0 || article.querySelector('video')) return;

      const btnContainer = createButton('快取下載 FB 照片', () => {
        // 動態獲取當前中央可見照片
        const viewportCenterY = window.innerHeight / 2;
        let targetImg = imgs[0];
        let minDist = Infinity;
        for (const img of imgs) {
          const rect = img.getBoundingClientRect();
          if (rect.width > 0 && rect.height > 0) {
            const dist = Math.abs((rect.top + rect.height / 2) - viewportCenterY);
            if (dist < minDist) {
              minDist = dist;
              targetImg = img;
            }
          }
        }
        const id = Date.now().toString().slice(-4);
        exportSpecificImage(targetImg, `Facebook_照片_${id}.jpg`);
      }, 'fb-photo-dl');

      if (getComputedStyle(article).position === 'static') {
        article.style.position = 'relative';
      }
      article.appendChild(btnContainer);
    });
  }

  // -------------------------------------------------------------------------
  // 7. 定期與變更監聽
  // -------------------------------------------------------------------------
  function scanAll() {
    scanInstagramFeed();
    scanInstagramStories();
    scanFacebook();
  }

  scanAll();
  const observer = new MutationObserver(() => {
    scanAll();
  });
  observer.observe(document.body, { childList: true, subtree: true });
})();
